# Memory Match Challenge

A fun and interactive memory card matching game that you can play anytime, anywhere!

## Features

- Three difficulty levels: Easy, Medium, and Hard
- Score tracking and high scores
- Timer to challenge yourself
- Dark/light theme toggle
- Responsive design for all devices
- Confetti celebration when you win
- Star rating system
- Local storage to save your high scores

## How to Play

1. Select a difficulty level (Easy, Medium, or Hard)
2. Click on cards to flip them over
3. Try to find matching pairs of emojis
4. Complete the game with the fewest moves and in the shortest time
5. Save your high score and try to beat it!

## Deployment Options

### Option 1: Simple Local Play

Just download the files and open `index.html` in your browser. No server required!

### Option 2: Deploy to GitHub Pages

1. Create a GitHub repository
2. Upload the game files
3. Enable GitHub Pages in your repository settings
4. Your game will be available at `https://yourusername.github.io/repository-name`

### Option 3: Deploy to Netlify

1. Create a Netlify account
2. Drag and drop the game folder to Netlify's upload area
3. Your game will be instantly deployed with a unique URL

## Customization

Feel free to customize the game:
- Change the emojis in the JavaScript array
- Modify the colors in the CSS variables
- Add more difficulty levels
- Create new game modes

Enjoy the game!
