/**
 * Memory Match Challenge - Premium Animations
 * Advanced animation effects for the enhanced memory game
 */

class AnimationController {
    constructor() {
        this.animations = {
            cardFlip: this.cardFlipAnimation,
            cardMatch: this.cardMatchAnimation,
            cardMismatch: this.cardMismatchAnimation,
            gameStart: this.gameStartAnimation,
            gameWin: this.gameWinAnimation,
            buttonHover: this.buttonHoverAnimation
        };
    }

    /**
     * Initialize animations
     */
    init() {
        this.setupButtonAnimations();
        this.setupCardAnimations();
    }

    /**
     * Setup button hover animations
     */
    setupButtonAnimations() {
        const buttons = document.querySelectorAll('button');
        buttons.forEach(button => {
            button.addEventListener('mouseenter', () => {
                this.buttonHoverAnimation(button);
            });
        });
    }

    /**
     * Setup card animations
     */
    setupCardAnimations() {
        const cards = document.querySelectorAll('.card');
        cards.forEach(card => {
            card.addEventListener('mouseenter', () => {
                if (!card.classList.contains('flipped') && !card.classList.contains('matched')) {
                    gsap.to(card, {
                        y: -10,
                        duration: 0.3,
                        ease: "power2.out"
                    });
                }
            });

            card.addEventListener('mouseleave', () => {
                if (!card.classList.contains('flipped') && !card.classList.contains('matched')) {
                    gsap.to(card, {
                        y: 0,
                        duration: 0.3,
                        ease: "power2.out"
                    });
                }
            });
        });
    }

    /**
     * Card flip animation
     * @param {HTMLElement} card - The card element to animate
     */
    cardFlipAnimation(card) {
        const cardInner = card.querySelector('.card-inner');
        
        gsap.to(cardInner, {
            rotationY: card.classList.contains('flipped') ? 0 : 180,
            duration: 0.8,
            ease: "back.out(1.7)",
            onComplete: () => {
                if (!card.classList.contains('flipped')) {
                    card.classList.add('flipped');
                } else {
                    card.classList.remove('flipped');
                }
            }
        });
    }

    /**
     * Card match animation
     * @param {HTMLElement} card1 - First matched card
     * @param {HTMLElement} card2 - Second matched card
     */
    cardMatchAnimation(card1, card2) {
        const timeline = gsap.timeline();
        
        // Pulse animation
        timeline.to([card1, card2], {
            scale: 1.1,
            duration: 0.3,
            ease: "power2.out"
        });
        
        timeline.to([card1, card2], {
            scale: 1,
            duration: 0.3,
            ease: "power2.in"
        });
        
        // Add matched class
        timeline.call(() => {
            card1.classList.add('matched');
            card2.classList.add('matched');
        });
        
        // Particle effect
        timeline.call(() => {
            this.createParticles(card1);
            this.createParticles(card2);
        });
    }

    /**
     * Card mismatch animation
     * @param {HTMLElement} card1 - First card
     * @param {HTMLElement} card2 - Second card
     */
    cardMismatchAnimation(card1, card2) {
        const timeline = gsap.timeline();
        
        // Shake animation
        timeline.to([card1, card2], {
            x: 10,
            duration: 0.1,
            ease: "power2.inOut"
        });
        
        timeline.to([card1, card2], {
            x: -10,
            duration: 0.1,
            ease: "power2.inOut"
        });
        
        timeline.to([card1, card2], {
            x: 5,
            duration: 0.1,
            ease: "power2.inOut"
        });
        
        timeline.to([card1, card2], {
            x: -5,
            duration: 0.1,
            ease: "power2.inOut"
        });
        
        timeline.to([card1, card2], {
            x: 0,
            duration: 0.1,
            ease: "power2.inOut"
        });
        
        // Flip back
        timeline.call(() => {
            const cardInner1 = card1.querySelector('.card-inner');
            const cardInner2 = card2.querySelector('.card-inner');
            
            gsap.to(cardInner1, {
                rotationY: 0,
                duration: 0.5,
                ease: "power2.out",
                onComplete: () => {
                    card1.classList.remove('flipped');
                }
            });
            
            gsap.to(cardInner2, {
                rotationY: 0,
                duration: 0.5,
                ease: "power2.out",
                onComplete: () => {
                    card2.classList.remove('flipped');
                }
            });
        }, null, "+=0.5");
    }

    /**
     * Game start animation
     */
    gameStartAnimation() {
        const cards = document.querySelectorAll('.card');
        const gameInfo = document.querySelectorAll('.game-info div');
        const title = document.querySelector('h1');
        const subtitle = document.querySelector('.subtitle');
        
        // Reset all elements
        gsap.set([cards, gameInfo, title, subtitle], { opacity: 0, y: 20 });
        
        // Create timeline
        const timeline = gsap.timeline();
        
        // Animate title and subtitle
        timeline.to(title, {
            opacity: 1,
            y: 0,
            duration: 0.8,
            ease: "back.out(1.7)"
        });
        
        timeline.to(subtitle, {
            opacity: 1,
            y: 0,
            duration: 0.8,
            ease: "back.out(1.7)"
        }, "-=0.4");
        
        // Animate game info
        timeline.to(gameInfo, {
            opacity: 1,
            y: 0,
            duration: 0.5,
            stagger: 0.1,
            ease: "back.out(1.7)"
        }, "-=0.4");
        
        // Animate cards with stagger
        timeline.to(cards, {
            opacity: 1,
            y: 0,
            duration: 0.5,
            stagger: 0.05,
            ease: "back.out(1.7)"
        }, "-=0.2");
    }

    /**
     * Game win animation
     */
    gameWinAnimation() {
        // Create confetti
        this.createConfetti();
        
        // Animate modal
        const modal = document.querySelector('.modal');
        const modalContent = modal.querySelector('.modal-content');
        
        gsap.set(modal, { display: 'flex', opacity: 0 });
        gsap.set(modalContent, { y: 20, opacity: 0 });
        
        const timeline = gsap.timeline();
        
        timeline.to(modal, {
            opacity: 1,
            duration: 0.3,
            ease: "power2.out"
        });
        
        timeline.to(modalContent, {
            y: 0,
            opacity: 1,
            duration: 0.5,
            ease: "back.out(1.7)"
        }, "-=0.1");
    }

    /**
     * Button hover animation
     * @param {HTMLElement} button - The button element
     */
    buttonHoverAnimation(button) {
        gsap.to(button, {
            y: -3,
            boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)",
            duration: 0.3,
            ease: "power2.out"
        });
        
        button.addEventListener('mouseleave', () => {
            gsap.to(button, {
                y: 0,
                boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)",
                duration: 0.3,
                ease: "power2.out"
            });
        }, { once: true });
    }

    /**
     * Create particles for card match effect
     * @param {HTMLElement} element - The element to create particles around
     */
    createParticles(element) {
        const rect = element.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        
        const colors = ['#6366f1', '#818cf8', '#4f46e5', '#f59e0b', '#fbbf24'];
        
        for (let i = 0; i < 20; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            document.body.appendChild(particle);
            
            // Random position, size and color
            const size = Math.random() * 8 + 4;
            const color = colors[Math.floor(Math.random() * colors.length)];
            
            gsap.set(particle, {
                x: centerX,
                y: centerY,
                width: size,
                height: size,
                backgroundColor: color,
                borderRadius: '50%',
                position: 'fixed',
                zIndex: 1000
            });
            
            // Random direction and distance
            const angle = Math.random() * Math.PI * 2;
            const distance = Math.random() * 100 + 50;
            const destinationX = centerX + Math.cos(angle) * distance;
            const destinationY = centerY + Math.sin(angle) * distance;
            
            // Animate particle
            gsap.to(particle, {
                x: destinationX,
                y: destinationY,
                opacity: 0,
                duration: Math.random() * 1 + 0.5,
                ease: "power2.out",
                onComplete: () => {
                    particle.remove();
                }
            });
        }
    }

    /**
     * Create confetti for win celebration
     */
    createConfetti() {
        const colors = ['#6366f1', '#818cf8', '#4f46e5', '#f59e0b', '#fbbf24', '#10b981'];
        
        for (let i = 0; i < 150; i++) {
            const confetti = document.createElement('div');
            confetti.className = 'confetti';
            document.body.appendChild(confetti);
            
            // Random position, size, rotation and color
            const size = Math.random() * 10 + 5;
            const color = colors[Math.floor(Math.random() * colors.length)];
            const isRect = Math.random() > 0.5;
            const startX = Math.random() * window.innerWidth;
            const startRotation = Math.random() * 360;
            
            gsap.set(confetti, {
                x: startX,
                y: -100,
                width: size,
                height: isRect ? size : size * 0.4,
                backgroundColor: color,
                borderRadius: isRect ? '2px' : '50%',
                position: 'fixed',
                zIndex: 1000,
                rotation: startRotation
            });
            
            // Animate confetti
            gsap.to(confetti, {
                y: window.innerHeight + 100,
                rotation: startRotation + Math.random() * 360,
                x: startX + Math.sin(Math.random() * Math.PI * 2) * 200,
                duration: Math.random() * 3 + 2,
                ease: "power1.out",
                delay: Math.random() * 2,
                onComplete: () => {
                    confetti.remove();
                }
            });
        }
    }
}

// Export animation controller
const animationController = new AnimationController();
