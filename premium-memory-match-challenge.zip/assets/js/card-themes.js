/**
 * Memory Match Challenge - Card Themes
 * Implementation of premium card designs and themes
 */

class CardThemes {
    constructor() {
        // Available card themes
        this.themes = [
            {
                id: 'emoji',
                name: 'Emoji',
                description: 'Classic emoji characters',
                cardClass: 'theme-emoji',
                emojis: [
                    '😀', '😁', '😂', '🤣', '😃', '😄', '😅', '😆', 
                    '😉', '😊', '😋', '😎', '😍', '😘', '🥰', '😗', 
                    '😙', '😚', '🙂', '🤗', '🤩', '🤔', '🤨', '😐', 
                    '😑', '😶', '🙄', '😏', '😣', '😥', '😮', '🤐', 
                    '😯', '😪', '😫', '🥱', '😴', '😌', '😛', '😜', 
                    '😝', '🤤', '😒', '😓', '😔', '😕', '🙃', '🤑'
                ]
            },
            {
                id: 'animals',
                name: 'Animals',
                description: 'Cute animal characters',
                cardClass: 'theme-animals',
                emojis: [
                    '🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼',
                    '🐨', '🐯', '🦁', '🐮', '🐷', '🐸', '🐵', '🐔',
                    '🐧', '🐦', '🐤', '🦆', '🦅', '🦉', '🦇', '🐺',
                    '🐗', '🐴', '🦄', '🐝', '🐛', '🦋', '🐌', '🐞',
                    '🐜', '🦟', '🦗', '🕷️', '🦂', '🐢', '🐍', '🦎',
                    '🦖', '🦕', '🐙', '🦑', '🦐', '🦞', '🦀', '🐡'
                ]
            },
            {
                id: 'food',
                name: 'Food',
                description: 'Delicious food items',
                cardClass: 'theme-food',
                emojis: [
                    '🍎', '🍐', '🍊', '🍋', '🍌', '🍉', '🍇', '🍓',
                    '🍈', '🍒', '🍑', '🥭', '🍍', '🥥', '🥝', '🍅',
                    '🥑', '🍆', '🥔', '🥕', '🌽', '🌶️', '🥒', '🥬',
                    '🥦', '🧄', '🧅', '🍄', '🥜', '🌰', '🍞', '🥐',
                    '🥖', '🥨', '🥯', '🥞', '🧇', '🧀', '🍖', '🍗',
                    '🥩', '🥓', '🍔', '🍟', '🍕', '🌭', '🥪', '🌮'
                ]
            },
            {
                id: 'space',
                name: 'Space',
                description: 'Cosmic space elements',
                cardClass: 'theme-space',
                emojis: [
                    '🌟', '⭐', '✨', '💫', '☄️', '🌠', '🌌', '🪐',
                    '🌍', '🌎', '🌏', '🌑', '🌒', '🌓', '🌔', '🌕',
                    '🌖', '🌗', '🌘', '🌙', '🚀', '🛸', '🛰️', '🔭',
                    '👨‍🚀', '👩‍🚀', '👽', '🛸', '🌠', '☄️', '🌌', '🪐',
                    '🌍', '🌎', '🌏', '🌑', '🌒', '🌓', '🌔', '🌕',
                    '🌖', '🌗', '🌘', '🌙', '🚀', '🛸', '🛰️', '🔭'
                ]
            },
            {
                id: 'fantasy',
                name: 'Fantasy',
                description: 'Magical fantasy elements',
                cardClass: 'theme-fantasy',
                emojis: [
                    '🧙‍♂️', '🧙‍♀️', '🧚‍♂️', '🧚‍♀️', '🧛‍♂️', '🧛‍♀️', '🧜‍♂️', '🧜‍♀️',
                    '🧝‍♂️', '🧝‍♀️', '🧞‍♂️', '🧞‍♀️', '🧟‍♂️', '🧟‍♀️', '👻', '👽',
                    '🦄', '🐉', '🐲', '🌈', '✨', '💫', '⚡', '🔮',
                    '⚔️', '🛡️', '👑', '💎', '🏰', '🗝️', '📜', '⏳',
                    '🧙‍♂️', '🧙‍♀️', '🧚‍♂️', '🧚‍♀️', '🧛‍♂️', '🧛‍♀️', '🧜‍♂️', '🧜‍♀️',
                    '🧝‍♂️', '🧝‍♀️', '🧞‍♂️', '🧞‍♀️', '🧟‍♂️', '🧟‍♀️', '👻', '👽'
                ]
            }
        ];
        
        // Special card designs
        this.specialCardDesigns = {
            wildcard: {
                emoji: '🃏',
                class: 'special-wildcard'
            },
            reveal: {
                emoji: '👁️',
                class: 'special-reveal'
            },
            bonus: {
                emoji: '💎',
                class: 'special-bonus'
            },
            time: {
                emoji: '⏱️',
                class: 'special-time'
            },
            shuffle: {
                emoji: '🔄',
                class: 'special-shuffle'
            },
            freeze: {
                emoji: '❄️',
                class: 'special-freeze'
            }
        };
    }
    
    /**
     * Get a theme by ID
     * @param {string} themeId - Theme ID
     * @returns {Object} Theme object
     */
    getTheme(themeId) {
        return this.themes.find(theme => theme.id === themeId) || this.themes[0];
    }
    
    /**
     * Get emojis for a specific theme
     * @param {string} themeId - Theme ID
     * @returns {Array} Array of emoji characters
     */
    getThemeEmojis(themeId) {
        const theme = this.getTheme(themeId);
        return theme.emojis;
    }
    
    /**
     * Apply theme to game
     * @param {string} themeId - Theme ID
     */
    applyTheme(themeId) {
        const theme = this.getTheme(themeId);
        
        // Remove all theme classes
        document.body.classList.remove(...this.themes.map(t => t.cardClass));
        
        // Add current theme class
        if (theme.cardClass) {
            document.body.classList.add(theme.cardClass);
        }
        
        return theme;
    }
    
    /**
     * Get special card design
     * @param {string} type - Special card type
     * @returns {Object} Special card design
     */
    getSpecialCardDesign(type) {
        return this.specialCardDesigns[type] || {
            emoji: '🃏',
            class: 'special-card'
        };
    }
    
    /**
     * Create a card element with theme styling
     * @param {Object} card - Card data
     * @param {string} themeId - Current theme ID
     * @returns {HTMLElement} Card element
     */
    createCardElement(card, themeId) {
        const theme = this.getTheme(themeId);
        const cardElement = document.createElement('div');
        cardElement.className = 'card';
        cardElement.dataset.id = card.id;
        
        // Add state classes
        if (card.isFlipped) cardElement.classList.add('flipped');
        if (card.isMatched) cardElement.classList.add('matched');
        if (card.isFrozen) cardElement.classList.add('frozen');
        
        // Add theme class
        if (theme.cardClass) {
            cardElement.classList.add(theme.cardClass);
        }
        
        // Handle special cards
        if (card.isSpecial && card.specialType) {
            const specialDesign = this.getSpecialCardDesign(card.specialType);
            cardElement.classList.add('special-card');
            if (specialDesign.class) {
                cardElement.classList.add(specialDesign.class);
            }
        }
        
        // Create card inner structure
        cardElement.innerHTML = `
            <div class="card-inner">
                <div class="card-back"></div>
                <div class="card-front">${card.emoji}</div>
            </div>
        `;
        
        return cardElement;
    }
}

// Export card themes
window.CardThemes = CardThemes;
