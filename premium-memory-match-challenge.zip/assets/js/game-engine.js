/**
 * Memory Match Challenge - Premium Edition
 * Advanced game engine with enhanced mechanics and features
 */

class MemoryGame {
    constructor() {
        // Game state
        this.cards = [];
        this.flippedCards = [];
        this.matchedPairs = 0;
        this.totalPairs = 0;
        this.moves = 0;
        this.score = 0;
        this.gameStarted = false;
        this.gameTimer = null;
        this.seconds = 0;
        this.difficulty = 'easy';
        this.isLocked = false;
        this.gameMode = 'classic';
        this.comboCount = 0;
        this.lastMatchTime = 0;
        this.specialCardActive = false;
        
        // Game settings
        this.settings = {
            comboTimeWindow: 5, // seconds to maintain combo
            comboMultiplier: 1.5, // score multiplier for combos
            timeAttackDuration: 60, // seconds for time attack mode
            specialCardFrequency: 0.2, // probability of special card (0-1)
        };
        
        // Emojis for cards
        this.emojis = [
            '😀', '😁', '😂', '🤣', '😃', '😄', '😅', '😆', 
            '😉', '😊', '😋', '😎', '😍', '😘', '🥰', '😗', 
            '😙', '😚', '🙂', '🤗', '🤩', '🤔', '🤨', '😐', 
            '😑', '😶', '🙄', '😏', '😣', '😥', '😮', '🤐', 
            '😯', '😪', '😫', '🥱', '😴', '😌', '😛', '😜', 
            '😝', '🤤', '😒', '😓', '😔', '😕', '🙃', '🤑',
            '🌟', '💫', '⭐', '✨', '💥', '🔥', '🎯', '🎮'
        ];
        
        // Special card types
        this.specialCardTypes = [
            { type: 'wildcard', emoji: '🃏', effect: 'Matches with any card' },
            { type: 'reveal', emoji: '👁️', effect: 'Reveals all cards briefly' },
            { type: 'bonus', emoji: '💎', effect: 'Bonus points when matched' }
        ];
        
        // DOM elements
        this.gameBoard = document.getElementById('gameBoard');
        this.movesElement = document.getElementById('moves');
        this.timerElement = document.getElementById('timer');
        this.scoreElement = document.getElementById('score');
        this.comboElement = document.getElementById('combo');
        this.modeElement = document.getElementById('gameMode');
        
        // Initialize animation controller
        this.animationController = window.animationController || null;
    }
    
    /**
     * Initialize the game
     */
    init() {
        this.setupEventListeners();
        this.resetGame();
        this.createCards();
        this.renderCards();
        this.updateGameInfo();
        
        // Initialize animations if controller exists
        if (this.animationController) {
            this.animationController.init();
            this.animationController.gameStartAnimation();
        }
    }
    
    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Game control buttons
        document.getElementById('newGameBtn').addEventListener('click', () => this.resetAndStart());
        document.getElementById('highScoresBtn').addEventListener('click', () => this.displayHighScores());
        document.getElementById('playAgainBtn').addEventListener('click', () => {
            document.getElementById('winModal').style.display = 'none';
            this.resetAndStart();
        });
        document.getElementById('saveScoreBtn').addEventListener('click', () => this.saveHighScore());
        document.getElementById('themeToggle').addEventListener('click', () => this.toggleTheme());
        document.getElementById('closeHighScoresBtn').addEventListener('click', () => {
            document.getElementById('highScoresModal').style.display = 'none';
        });
        
        // Difficulty buttons
        document.querySelectorAll('.difficulty').forEach(button => {
            button.addEventListener('click', () => {
                this.setDifficulty(button.dataset.difficulty);
            });
        });
        
        // Game mode buttons
        document.querySelectorAll('.game-mode').forEach(button => {
            button.addEventListener('click', () => {
                this.setGameMode(button.dataset.mode);
            });
        });
        
        // Star rating
        document.querySelectorAll('.star').forEach(star => {
            star.addEventListener('click', () => {
                const rating = parseInt(star.dataset.rating);
                document.querySelectorAll('.star').forEach(s => {
                    s.classList.toggle('active', parseInt(s.dataset.rating) <= rating);
                });
            });
            
            star.addEventListener('mouseover', () => {
                const rating = parseInt(star.dataset.rating);
                document.querySelectorAll('.star').forEach(s => {
                    s.classList.toggle('active', parseInt(s.dataset.rating) <= rating);
                });
            });
        });
    }
    
    /**
     * Reset and start a new game
     */
    resetAndStart() {
        this.resetGame();
        this.createCards();
        this.renderCards();
        this.updateGameInfo();
    }
    
    /**
     * Reset game state
     */
    resetGame() {
        this.cards = [];
        this.flippedCards = [];
        this.matchedPairs = 0;
        this.moves = 0;
        this.score = 0;
        this.seconds = 0;
        this.comboCount = 0;
        this.gameStarted = false;
        this.isLocked = false;
        this.specialCardActive = false;
        clearInterval(this.gameTimer);
        this.updateGameInfo();
        
        // Reset timer for time attack mode
        if (this.gameMode === 'timeAttack') {
            this.seconds = this.settings.timeAttackDuration;
            this.timerElement.textContent = `Time: ${this.seconds}s`;
        }
    }
    
    /**
     * Create cards based on difficulty and game mode
     */
    createCards() {
        let pairCount;
        let gridColumns;
        
        // Set pair count and grid layout based on difficulty
        switch(this.difficulty) {
            case 'easy':
                pairCount = 6;
                gridColumns = 'repeat(3, 1fr)';
                break;
            case 'medium':
                pairCount = 8;
                gridColumns = 'repeat(4, 1fr)';
                break;
            case 'hard':
                pairCount = 12;
                gridColumns = 'repeat(4, 1fr)';
                break;
            case 'expert':
                pairCount = 15;
                gridColumns = 'repeat(5, 1fr)';
                break;
            default:
                pairCount = 6;
                gridColumns = 'repeat(3, 1fr)';
        }
        
        this.gameBoard.style.gridTemplateColumns = gridColumns;
        this.totalPairs = pairCount;
        
        // Shuffle and select emojis
        const shuffledEmojis = [...this.emojis].sort(() => 0.5 - Math.random()).slice(0, pairCount);
        
        // Create pairs
        let cardPairs = [...shuffledEmojis, ...shuffledEmojis];
        
        // Add special cards based on game mode and settings
        if (this.gameMode !== 'zen' && Math.random() < this.settings.specialCardFrequency) {
            // Replace a random pair with a special card pair
            const specialCardIndex = Math.floor(Math.random() * this.specialCardTypes.length);
            const specialCard = this.specialCardTypes[specialCardIndex];
            const replaceIndex = Math.floor(Math.random() * pairCount);
            
            // Replace both cards in the pair
            cardPairs[replaceIndex] = specialCard.emoji;
            cardPairs[replaceIndex + pairCount] = specialCard.emoji;
        }
        
        // Shuffle pairs
        this.cards = cardPairs.sort(() => 0.5 - Math.random()).map((emoji, index) => {
            const isSpecial = this.specialCardTypes.some(card => card.emoji === emoji);
            const specialType = isSpecial ? 
                this.specialCardTypes.find(card => card.emoji === emoji).type : null;
                
            return {
                id: index,
                emoji: emoji,
                isFlipped: false,
                isMatched: false,
                isSpecial: isSpecial,
                specialType: specialType
            };
        });
    }
    
    /**
     * Render cards on the game board
     */
    renderCards() {
        this.gameBoard.innerHTML = '';
        
        this.cards.forEach(card => {
            const cardElement = document.createElement('div');
            cardElement.className = 'card';
            cardElement.dataset.id = card.id;
            
            if (card.isFlipped) cardElement.classList.add('flipped');
            if (card.isMatched) cardElement.classList.add('matched');
            if (card.isSpecial) cardElement.classList.add('special-card');
            
            cardElement.innerHTML = `
                <div class="card-inner">
                    <div class="card-back"></div>
                    <div class="card-front">${card.emoji}</div>
                </div>
            `;
            
            cardElement.addEventListener('click', () => this.flipCard(card.id));
            this.gameBoard.appendChild(cardElement);
        });
    }
    
    /**
     * Flip a card
     * @param {number} id - Card ID
     */
    flipCard(id) {
        // Prevent flipping if game is locked or card is already flipped/matched
        if (this.isLocked) return;
        
        const card = this.cards.find(card => card.id === id);
        
        if (card.isFlipped || card.isMatched) return;
        
        // Start the timer on first card flip
        if (!this.gameStarted) {
            this.startTimer();
            this.gameStarted = true;
        }
        
        // Flip the card
        card.isFlipped = true;
        this.flippedCards.push(card);
        
        // Use animation if available
        const cardElement = document.querySelector(`.card[data-id="${id}"]`);
        if (this.animationController) {
            this.animationController.cardFlipAnimation(cardElement);
        } else {
            // Fallback to CSS class toggle
            this.renderCards();
        }
        
        // Check for match if two cards are flipped
        if (this.flippedCards.length === 2) {
            this.moves++;
            this.updateGameInfo();
            this.checkForMatch();
        }
    }
    
    /**
     * Check if the flipped cards match
     */
    checkForMatch() {
        this.isLocked = true;
        
        const [card1, card2] = this.flippedCards;
        const card1Element = document.querySelector(`.card[data-id="${card1.id}"]`);
        const card2Element = document.querySelector(`.card[data-id="${card2.id}"]`);
        
        // Check for special card interactions
        if (card1.isSpecial || card2.isSpecial) {
            this.handleSpecialCardMatch(card1, card2, card1Element, card2Element);
            return;
        }
        
        if (card1.emoji === card2.emoji) {
            // Match found
            setTimeout(() => {
                card1.isMatched = true;
                card2.isMatched = true;
                this.matchedPairs++;
                
                // Check for combo (quick successive matches)
                const now = Date.now();
                if (now - this.lastMatchTime < this.settings.comboTimeWindow * 1000) {
                    this.comboCount++;
                    // Apply combo multiplier to score
                    this.score += Math.floor(10 * Math.pow(this.settings.comboMultiplier, this.comboCount) * 
                        (this.difficulty === 'easy' ? 1 : 
                         this.difficulty === 'medium' ? 2 : 
                         this.difficulty === 'hard' ? 3 : 4));
                } else {
                    this.comboCount = 0;
                    // Regular score
                    this.score += 10 * (this.difficulty === 'easy' ? 1 : 
                                       this.difficulty === 'medium' ? 2 : 
                                       this.difficulty === 'hard' ? 3 : 4);
                }
                
                this.lastMatchTime = now;
                this.updateGameInfo();
                
                // Use animation if available
                if (this.animationController) {
                    this.animationController.cardMatchAnimation(card1Element, card2Element);
                } else {
                    card1Element.classList.add('matched');
                    card2Element.classList.add('matched');
                }
                
                // Check if game is complete
                if (this.matchedPairs === this.totalPairs) {
                    this.endGame();
                }
                
                this.flippedCards = [];
                this.isLocked = false;
            }, 500);
        } else {
            // No match
            setTimeout(() => {
                // Reset combo on mismatch
                this.comboCount = 0;
                this.updateGameInfo();
                
                // Use animation if available
                if (this.animationController) {
                    this.animationController.cardMismatchAnimation(card1Element, card2Element);
                } else {
                    card1.isFlipped = false;
                    card2.isFlipped = false;
                    this.renderCards();
                }
                
                this.flippedCards = [];
                this.isLocked = false;
            }, 1000);
        }
    }
    
    /**
     * Handle special card matches
     * @param {Object} card1 - First card
     * @param {Object} card2 - Second card
     * @param {HTMLElement} card1Element - First card element
     * @param {HTMLElement} card2Element - Second card element
     */
    handleSpecialCardMatch(card1, card2, card1Element, card2Element) {
        // Prevent multiple special card activations
        if (this.specialCardActive) {
            this.flippedCards = [];
            this.isLocked = false;
            return;
        }
        
        this.specialCardActive = true;
        
        // Get the special card (if both are special, use the first one)
        const specialCard = card1.isSpecial ? card1 : card2;
        const specialCardElement = card1.isSpecial ? card1Element : card2Element;
        const otherCard = card1.isSpecial ? card2 : card1;
        const otherCardElement = card1.isSpecial ? card2Element : card1Element;
        
        switch (specialCard.specialType) {
            case 'wildcard':
                // Wildcard matches with any card
                setTimeout(() => {
                    specialCard.isMatched = true;
                    otherCard.isMatched = true;
                    this.matchedPairs++;
                    
                    // Bonus points for wildcard match
                    this.score += 20 * (this.difficulty === 'easy' ? 1 : 
                                      this.difficulty === 'medium' ? 2 : 
                                      this.difficulty === 'hard' ? 3 : 4);
                    this.updateGameInfo();
                    
                    // Use animation if available
                    if (this.animationController) {
                        this.animationController.cardMatchAnimation(specialCardElement, otherCardElement);
                    } else {
                        specialCardElement.classList.add('matched');
                        otherCardElement.classList.add('matched');
                    }
                    
                    // Check if game is complete
                    if (this.matchedPairs === this.totalPairs) {
                        this.endGame();
                    }
                    
                    this.flippedCards = [];
                    this.isLocked = false;
                    this.specialCardActive = false;
                }, 500);
                break;
                
            case 'reveal':
                // Reveal all cards briefly
                setTimeout(() => {
                    // Flip all unmatched cards
                    const unmatched = this.cards.filter(c => !c.isMatched && !c.isFlipped);
                    unmatched.forEach(c => {
                        c.isFlipped = true;
                    });
                    this.renderCards();
                    
                    // Flip them back after a delay
                    setTimeout(() => {
                        unmatched.forEach(c => {
                            c.isFlipped = false;
                        });
                        
                        // Keep the special card and its pair flipped
                        specialCard.isFlipped = true;
                        otherCard.isFlipped = true;
                        
                        this.renderCards();
                        this.flippedCards = [specialCard, otherCard];
                        this.isLocked = false;
                        this.specialCardActive = false;
                        
                        // Continue checking for match
                        this.checkForMatch();
                    }, 2000);
                }, 500);
                break;
                
            case 'bonus':
                // Bonus points when matched
                if (specialCard.emoji === otherCard.emoji) {
                    setTimeout(() => {
                        specialCard.isMatched = true;
                        otherCard.isMatched = true;
                        this.matchedPairs++;
                        
                        // Extra bonus points
                        this.score += 50 * (this.difficulty === 'easy' ? 1 : 
                                          this.difficulty === 'medium' ? 2 : 
                                          this.difficulty === 'hard' ? 3 : 4);
                        this.updateGameInfo();
                        
                        // Use animation if available
                        if (this.animationController) {
                            this.animationController.cardMatchAnimation(specialCardElement, otherCardElement);
                        } else {
                            specialCardElement.classList.add('matched');
                            otherCardElement.classList.add('matched');
                        }
                        
                        // Check if game is complete
                        if (this.matchedPairs === this.totalPairs) {
                            this.endGame();
                        }
                        
                        this.flippedCards = [];
                        this.isLocked = false;
                        this.specialCardActive = false;
                    }, 500);
                } else {
                    // No match
                    setTimeout(() => {
                        // Use animation if available
                        if (this.animationController) {
                            this.animationController.cardMismatchAnimation(specialCardElement, otherCardElement);
                        } else {
                            specialCard.isFlipped = false;
                            otherCard.isFlipped = false;
                            this.renderCards();
                        }
                        
                        this.flippedCards = [];
                        this.isLocked = false;
                        this.specialCardActive = false;
                    }, 1000);
                }
                break;
                
            default:
                // Default behavior for unknown special card types
                this.flippedCards = [];
                this.isLocked = false;
                this.specialCardActive = false;
        }
    }
    
    /**
     * Start the game timer
     */
    startTimer() {
        clearInterval(this.gameTimer);
        
        if (this.gameMode === 'timeAttack') {
            // Time attack mode: countdown timer
            this.seconds = this.settings.timeAttackDuration;
            this.gameTimer = setInterval(() => {
                this.seconds--;
                this.timerElement.textContent = `Time: ${this.seconds}s`;
                
                // Time's up
                if (this.seconds <= 0) {
                    clearInterval(this.gameTimer);
                    this.endGame(true);
                }
            }, 1000);
        } else {
            // Classic and zen modes: count up timer
            this.seconds = 0;
            this.gameTimer = setInterval(() => {
                this.seconds++;
                this.timerElement.textContent = `Time: ${this.seconds}s`;
            }, 1000);
        }
    }
    
    /**
     * Update game information display
     */
    updateGameInfo() {
        this.movesElement.textContent = `Moves: ${this.moves}`;
        this.timerElement.textContent = `Time: ${this.seconds}s`;
        this.scoreElement.textContent = `Score: ${this.score}`;
        
        // Update combo display if available
        if (this.comboElement) {
            if (this.comboCount > 0) {
                this.comboElement.textContent = `Combo: x${this.comboCount + 1}`;
                this.comboElement.classList.add('active');
            } else {
                this.comboElement.textContent = 'Combo: x1';
                this.comboElement.classList.remove('active');
            }
        }
        
        // Update game mode display if available
        if (this.modeElement) {
            let modeName = 'Classic';
            if (this.gameMode === 'timeAttack') modeName = 'Time Attack';
            if (this.gameMode === 'zen') modeName = 'Zen Mode';
            this.modeElement.textContent = `Mode: ${modeName}`;
        }
    }
    
    /**
     * End the game
     * @param {boolean} timeUp - Whether the game ended due to time running out
     */
    endGame(timeUp = false) {
        clearInterval(this.gameTimer);
        
        if (!timeUp) {
            // Calculate final score with time bonus for classic mode
            if (this.gameMode === 'classic') {
                const timeBonus = Math.max(0, 100 - this.seconds);
                this.score += timeBonus;
            }
        }
        
        // Update final stats
        document.getElementById('finalMoves').textContent = this.moves;
        document.getElementById('finalTime').textContent = this.seconds;
        document.getElementById('finalScore').textContent = this.score;
        
        // Show appropriate modal
        setTimeout(() => {
            const winModal = document.getElementById('winModal');
            
            // Update modal title based on game outcome
            const modalTitle = document.querySelector('#winModal h2');
            if (timeUp && this.matchedPairs < this.totalPairs) {
                modalTitle.textContent = 'Time\'s Up!';
            } else {
                modalTitle.textContent = 'Congratulations!';
            }
            
            // Show modal with animation if available
            if (this.animationController) {
                this.animationController.gameWinAnimation();
            } else {
                winModal.style.display = 'flex';
                this.createConfetti();
            }
        }, 500);
    }
    
    /**
     * Create confetti effect
     */
    createConfetti() {
        if (this.animationController) return; // Skip if animation controller exists
        
        const colors = ['#6366f1', '#818cf8', '#4f46e5', '#f59e0b', '#fbbf24', '#10b981'];
        
        for (let i = 0; i < 100; i++) {
            const confetti = document.createElement('div');
            confetti.className = 'confetti';
            confetti.style.left = `${Math.random() * 100}%`;
            confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
            confetti.style.width = `${Math.random() * 10 + 5}px`;
            confetti.style.height = `${Math.random() * 10 + 5}px`;
            confetti.style.animationDelay = `${Math.random() * 2}s`;
            document.body.appendChild(confetti);
            
            // Remove confetti after animation
            setTimeout(() => {
                confetti.remove();
            }, 3000);
        }
    }
    
    /**
     * Save high score
     */
    saveHighScore() {
        const playerName = document.getElementById('playerName').value.trim() || 'Anonymous';
        const rating = document.querySelectorAll('.star.active').length;
        
        // Get existing high scores
        let highScores = JSON.parse(localStorage.getItem('memoryGameHighScores')) || {
            easy: { classic: [], timeAttack: [], zen: [] },
            medium: { classic: [], timeAttack: [], zen: [] },
            hard: { classic: [], timeAttack: [], zen: [] },
            expert: { classic: [], timeAttack: [], zen: [] }
        };
        
        // Ensure the structure exists
        if (!highScores[this.difficulty]) {
            highScores[this.difficulty] = { classic: [], timeAttack: [], zen: [] };
        }
        
        if (!highScores[this.difficulty][this.gameMode]) {
            highScores[this.difficulty][this.gameMode] = [];
        }
        
        // Add new score
        highScores[this.difficulty][this.gameMode].push({
            name: playerName,
            score: this.score,
            moves: this.moves,
            time: this.seconds,
            rating: rating,
            date: new Date().toISOString()
        });
        
        // Sort scores
        highScores[this.difficulty][this.gameMode].sort((a, b) => b.score - a.score);
        
        // Keep only top 10
        highScores[this.difficulty][this.gameMode] = highScores[this.difficulty][this.gameMode].slice(0, 10);
        
        // Save to localStorage
        localStorage.setItem('memoryGameHighScores', JSON.stringify(highScores));
        
        // Close modal
        document.getElementById('winModal').style.display = 'none';
    }
    
    /**
     * Display high scores
     */
    displayHighScores() {
        const highScores = JSON.parse(localStorage.getItem('memoryGameHighScores')) || {
            easy: { classic: [], timeAttack: [], zen: [] },
            medium: { classic: [], timeAttack: [], zen: [] },
            hard: { classic: [], timeAttack: [], zen: [] },
            expert: { classic: [], timeAttack: [], zen: [] }
        };
        
        // Get containers for each difficulty and mode
        const containers = {
            easy: {
                classic: document.getElementById('easyClassicScores'),
                timeAttack: document.getElementById('easyTimeAttackScores'),
                zen: document.getElementById('easyZenScores')
            },
            medium: {
                classic: document.getElementById('mediumClassicScores'),
                timeAttack: document.getElementById('mediumTimeAttackScores'),
                zen: document.getElementById('mediumZenScores')
            },
            hard: {
                classic: document.getElementById('hardClassicScores'),
                timeAttack: document.getElementById('hardTimeAttackScores'),
                zen: document.getElementById('hardZenScores')
            },
            expert: {
                classic: document.getElementById('expertClassicScores'),
                timeAttack: document.getElementById('expertTimeAttackScores'),
                zen: document.getElementById('expertZenScores')
            }
        };
        
        // Populate scores for each difficulty and mode
        for (const difficulty in highScores) {
            for (const mode in highScores[difficulty]) {
                const container = containers[difficulty]?.[mode];
                if (container) {
                    container.innerHTML = '';
                    
                    if (highScores[difficulty][mode].length === 0) {
                        const li = document.createElement('li');
                        li.textContent = 'No scores yet';
                        container.appendChild(li);
                    } else {
                        highScores[difficulty][mode].forEach((score, index) => {
                            const li = document.createElement('li');
                            li.innerHTML = `
                                <span class="rank">#${index + 1}</span>
                                <span class="name">${score.name}</span>
                                <span class="score">${score.score} pts</span>
                                <span class="details">${score.moves} moves, ${score.time}s</span>
                            `;
                            container.appendChild(li);
                        });
                    }
                }
            }
        }
        
        // Show modal
        document.getElementById('highScoresModal').style.display = 'flex';
    }
    
    /**
     * Toggle dark/light theme
     */
    toggleTheme() {
        document.body.classList.toggle('dark-mode');
        document.getElementById('themeToggle').textContent = document.body.classList.contains('dark-mode') ? '☀️' : '🌙';
        
        // Save preference
        localStorage.setItem('memoryGameDarkMode', document.body.classList.contains('dark-mode'));
    }
    
    /**
     * Set difficulty
     * @param {string} newDifficulty - New difficulty level
     */
    setDifficulty(newDifficulty) {
        this.difficulty = newDifficulty;
        
        // Update active button
        document.querySelectorAll('.difficulty').forEach(button => {
            button.classList.toggle('active', button.dataset.difficulty === this.difficulty);
        });
        
        this.resetAndStart();
    }
    
    /**
     * Set game mode
     * @param {string} newMode - New game mode
     */
    setGameMode(newMode) {
        this.gameMode = newMode;
        
        // Update active button
        document.querySelectorAll('.game-mode').forEach(button => {
            button.classList.toggle('active', button.dataset.mode === this.gameMode);
        });
        
        this.resetAndStart();
    }
}

// Initialize game when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Load theme preference
    if (localStorage.getItem('memoryGameDarkMode') === 'true') {
        document.body.classList.add('dark-mode');
        document.getElementById('themeToggle').textContent = '☀️';
    }
    
    // Initialize game
    const game = new MemoryGame();
    game.init();
    
    // Make game instance globally available
    window.memoryGame = game;
});
