/**
 * Memory Match Challenge - Leaderboards System
 * Implementation of global and local leaderboards with detailed statistics
 */

class LeaderboardsSystem {
    constructor() {
        this.localLeaderboards = {};
        this.leaderboardCategories = [
            'classic',
            'timeAttack',
            'zen'
        ];
        
        this.difficultyLevels = [
            'easy',
            'medium',
            'hard',
            'expert'
        ];
        
        // Maximum entries per leaderboard
        this.maxEntries = 10;
    }
    
    /**
     * Initialize leaderboards system
     */
    init() {
        this.loadLocalLeaderboards();
        this.renderLeaderboards();
    }
    
    /**
     * Load leaderboards from localStorage
     */
    loadLocalLeaderboards() {
        const savedData = localStorage.getItem('memoryGameLeaderboards');
        if (savedData) {
            this.localLeaderboards = JSON.parse(savedData);
        } else {
            // Initialize empty leaderboards structure
            this.difficultyLevels.forEach(difficulty => {
                this.localLeaderboards[difficulty] = {};
                
                this.leaderboardCategories.forEach(category => {
                    this.localLeaderboards[difficulty][category] = [];
                });
            });
            
            this.saveLocalLeaderboards();
        }
    }
    
    /**
     * Save leaderboards to localStorage
     */
    saveLocalLeaderboards() {
        localStorage.setItem('memoryGameLeaderboards', JSON.stringify(this.localLeaderboards));
    }
    
    /**
     * Add score to leaderboard
     * @param {Object} scoreData - Score data object
     * @returns {Object} Result with position information
     */
    addScore(scoreData) {
        const { playerName, score, moves, time, difficulty, gameMode } = scoreData;
        
        if (!playerName || !this.difficultyLevels.includes(difficulty) || !this.leaderboardCategories.includes(gameMode)) {
            return { success: false, message: 'Invalid score data' };
        }
        
        // Create score entry
        const entry = {
            playerName,
            score,
            moves,
            time,
            date: new Date().toISOString()
        };
        
        // Get current leaderboard
        const leaderboard = this.localLeaderboards[difficulty][gameMode];
        
        // Add entry
        leaderboard.push(entry);
        
        // Sort based on game mode
        if (gameMode === 'classic' || gameMode === 'timeAttack') {
            // Higher score is better
            leaderboard.sort((a, b) => b.score - a.score);
        } else if (gameMode === 'zen') {
            // Lower moves is better
            leaderboard.sort((a, b) => a.moves - b.moves);
        }
        
        // Trim to max entries
        if (leaderboard.length > this.maxEntries) {
            leaderboard.length = this.maxEntries;
        }
        
        // Save updated leaderboards
        this.saveLocalLeaderboards();
        
        // Find position of new entry
        const position = leaderboard.findIndex(e => 
            e.playerName === playerName && 
            e.score === score && 
            e.moves === moves && 
            e.time === time
        );
        
        // Render updated leaderboards
        this.renderLeaderboards();
        
        return { 
            success: true, 
            position: position + 1,
            isTopScore: position === 0,
            totalEntries: leaderboard.length
        };
    }
    
    /**
     * Render leaderboards in the UI
     */
    renderLeaderboards() {
        this.difficultyLevels.forEach(difficulty => {
            this.leaderboardCategories.forEach(category => {
                const leaderboard = this.localLeaderboards[difficulty][category];
                const containerId = `${difficulty}${category.charAt(0).toUpperCase() + category.slice(1)}Scores`;
                const container = document.getElementById(containerId);
                
                if (container) {
                    container.innerHTML = '';
                    
                    if (leaderboard.length === 0) {
                        container.innerHTML = '<li class="no-scores">No scores yet</li>';
                        return;
                    }
                    
                    leaderboard.forEach((entry, index) => {
                        const listItem = document.createElement('li');
                        
                        // Format date
                        const date = new Date(entry.date);
                        const formattedDate = `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;
                        
                        // Format details based on game mode
                        let details;
                        if (category === 'classic') {
                            details = `${entry.moves} moves, ${entry.time}s`;
                        } else if (category === 'timeAttack') {
                            details = `${entry.time}s`;
                        } else if (category === 'zen') {
                            details = `${entry.moves} moves`;
                        }
                        
                        listItem.innerHTML = `
                            <span class="rank">${index + 1}</span>
                            <span class="name">${entry.playerName}</span>
                            <span class="score">${entry.score}</span>
                            <span class="details">${details}</span>
                        `;
                        
                        // Highlight top 3
                        if (index < 3) {
                            listItem.classList.add(`rank-${index + 1}`);
                        }
                        
                        container.appendChild(listItem);
                    });
                }
            });
        });
    }
    
    /**
     * Check if score qualifies for leaderboard
     * @param {Object} scoreData - Score data object
     * @returns {boolean} Whether score qualifies
     */
    qualifiesForLeaderboard(scoreData) {
        const { score, moves, difficulty, gameMode } = scoreData;
        
        if (!this.difficultyLevels.includes(difficulty) || !this.leaderboardCategories.includes(gameMode)) {
            return false;
        }
        
        const leaderboard = this.localLeaderboards[difficulty][gameMode];
        
        // If leaderboard isn't full yet, score qualifies
        if (leaderboard.length < this.maxEntries) {
            return true;
        }
        
        // Check based on game mode
        if (gameMode === 'classic' || gameMode === 'timeAttack') {
            // Higher score is better
            const lowestScore = leaderboard[leaderboard.length - 1].score;
            return score > lowestScore;
        } else if (gameMode === 'zen') {
            // Lower moves is better
            const highestMoves = leaderboard[leaderboard.length - 1].moves;
            return moves < highestMoves;
        }
        
        return false;
    }
    
    /**
     * Get player's best score
     * @param {string} playerName - Player name
     * @param {string} difficulty - Difficulty level
     * @param {string} gameMode - Game mode
     * @returns {Object|null} Best score entry or null
     */
    getPlayerBestScore(playerName, difficulty, gameMode) {
        if (!this.difficultyLevels.includes(difficulty) || !this.leaderboardCategories.includes(gameMode)) {
            return null;
        }
        
        const leaderboard = this.localLeaderboards[difficulty][gameMode];
        const playerEntries = leaderboard.filter(entry => entry.playerName === playerName);
        
        if (playerEntries.length === 0) {
            return null;
        }
        
        // Sort based on game mode
        if (gameMode === 'classic' || gameMode === 'timeAttack') {
            // Higher score is better
            return playerEntries.sort((a, b) => b.score - a.score)[0];
        } else if (gameMode === 'zen') {
            // Lower moves is better
            return playerEntries.sort((a, b) => a.moves - b.moves)[0];
        }
        
        return null;
    }
    
    /**
     * Clear all leaderboards
     */
    clearAllLeaderboards() {
        this.difficultyLevels.forEach(difficulty => {
            this.leaderboardCategories.forEach(category => {
                this.localLeaderboards[difficulty][category] = [];
            });
        });
        
        this.saveLocalLeaderboards();
        this.renderLeaderboards();
    }
    
    /**
     * Export leaderboards data
     * @returns {string} JSON string of leaderboards data
     */
    exportLeaderboards() {
        return JSON.stringify(this.localLeaderboards);
    }
    
    /**
     * Import leaderboards data
     * @param {string} data - JSON string of leaderboards data
     * @returns {boolean} Success status
     */
    importLeaderboards(data) {
        try {
            const parsedData = JSON.parse(data);
            
            // Validate structure
            let isValid = true;
            this.difficultyLevels.forEach(difficulty => {
                if (!parsedData[difficulty]) isValid = false;
                
                this.leaderboardCategories.forEach(category => {
                    if (!parsedData[difficulty][category]) isValid = false;
                    if (!Array.isArray(parsedData[difficulty][category])) isValid = false;
                });
            });
            
            if (!isValid) {
                return false;
            }
            
            this.localLeaderboards = parsedData;
            this.saveLocalLeaderboards();
            this.renderLeaderboards();
            return true;
        } catch (error) {
            console.error('Error importing leaderboards:', error);
            return false;
        }
    }
}

// Export leaderboards system
window.LeaderboardsSystem = LeaderboardsSystem;
