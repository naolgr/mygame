/**
 * Memory Match Challenge - Multiplayer Mode
 * Implementation of competitive and cooperative multiplayer features
 */

class MultiplayerSystem {
    constructor(gameInstance) {
        this.game = gameInstance;
        this.isMultiplayerActive = false;
        this.players = [];
        this.currentPlayerIndex = 0;
        this.maxPlayers = 4;
        this.gameMode = 'competitive'; // 'competitive' or 'cooperative'
        
        // Player colors for visual identification
        this.playerColors = [
            {primary: '#6366f1', secondary: '#818cf8'}, // Purple
            {primary: '#f59e0b', secondary: '#fbbf24'}, // Orange
            {primary: '#10b981', secondary: '#34d399'}, // Green
            {primary: '#ef4444', secondary: '#f87171'}  // Red
        ];
    }
    
    /**
     * Initialize multiplayer system
     */
    init() {
        this.createMultiplayerUI();
        this.setupEventListeners();
    }
    
    /**
     * Create multiplayer UI elements
     */
    createMultiplayerUI() {
        // Create multiplayer button in main menu
        const controlsContainer = document.querySelector('.controls');
        if (controlsContainer) {
            const multiplayerBtn = document.createElement('button');
            multiplayerBtn.id = 'multiplayerBtn';
            multiplayerBtn.textContent = 'Multiplayer';
            controlsContainer.appendChild(multiplayerBtn);
        }
        
        // Create multiplayer modal
        const multiplayerModal = document.createElement('div');
        multiplayerModal.id = 'multiplayerModal';
        multiplayerModal.className = 'modal';
        
        multiplayerModal.innerHTML = `
            <div class="modal-content">
                <h2>Multiplayer Mode</h2>
                
                <div class="settings-section">
                    <h3>Game Mode</h3>
                    <div class="mode-selector">
                        <button class="multiplayer-mode active" data-mode="competitive">Competitive</button>
                        <button class="multiplayer-mode" data-mode="cooperative">Cooperative</button>
                    </div>
                    <p class="mode-description" id="modeDescription">
                        Competitive: Players take turns and compete for the highest score.
                    </p>
                </div>
                
                <div class="settings-section">
                    <h3>Players</h3>
                    <div class="player-list" id="playerList">
                        <div class="player-item">
                            <div class="player-color" style="background-color: #6366f1;"></div>
                            <input type="text" class="player-name" value="Player 1" maxlength="15">
                            <button class="remove-player" disabled>✕</button>
                        </div>
                        <div class="player-item">
                            <div class="player-color" style="background-color: #f59e0b;"></div>
                            <input type="text" class="player-name" value="Player 2" maxlength="15">
                            <button class="remove-player">✕</button>
                        </div>
                    </div>
                    
                    <button id="addPlayerBtn" class="add-player-btn">Add Player</button>
                </div>
                
                <div class="controls">
                    <button id="startMultiplayerBtn">Start Game</button>
                    <button id="closeMultiplayerBtn">Cancel</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(multiplayerModal);
        
        // Create player scoreboard for in-game display
        const scoreboard = document.createElement('div');
        scoreboard.id = 'playerScoreboard';
        scoreboard.className = 'player-scoreboard';
        scoreboard.style.display = 'none';
        
        document.querySelector('.container').insertBefore(
            scoreboard, 
            document.getElementById('gameBoard')
        );
    }
    
    /**
     * Setup event listeners for multiplayer UI
     */
    setupEventListeners() {
        // Open multiplayer modal
        document.getElementById('multiplayerBtn').addEventListener('click', () => {
            document.getElementById('multiplayerModal').style.display = 'flex';
        });
        
        // Close multiplayer modal
        document.getElementById('closeMultiplayerBtn').addEventListener('click', () => {
            document.getElementById('multiplayerModal').style.display = 'none';
        });
        
        // Start multiplayer game
        document.getElementById('startMultiplayerBtn').addEventListener('click', () => {
            this.startMultiplayerGame();
        });
        
        // Add player
        document.getElementById('addPlayerBtn').addEventListener('click', () => {
            this.addPlayer();
        });
        
        // Game mode selection
        const modeBtns = document.querySelectorAll('.multiplayer-mode');
        modeBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                modeBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.gameMode = btn.dataset.mode;
                
                // Update description
                const description = document.getElementById('modeDescription');
                if (this.gameMode === 'competitive') {
                    description.textContent = 'Competitive: Players take turns and compete for the highest score.';
                } else {
                    description.textContent = 'Cooperative: Players work together to complete the game with the fewest moves.';
                }
            });
        });
        
        // Remove player buttons
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('remove-player')) {
                const playerItem = e.target.closest('.player-item');
                if (playerItem && document.querySelectorAll('.player-item').length > 2) {
                    playerItem.remove();
                    this.updatePlayerColors();
                }
            }
        });
    }
    
    /**
     * Add a new player to the list
     */
    addPlayer() {
        const playerList = document.getElementById('playerList');
        const playerCount = playerList.querySelectorAll('.player-item').length;
        
        if (playerCount < this.maxPlayers) {
            const playerItem = document.createElement('div');
            playerItem.className = 'player-item';
            
            const playerColor = this.playerColors[playerCount];
            
            playerItem.innerHTML = `
                <div class="player-color" style="background-color: ${playerColor.primary};"></div>
                <input type="text" class="player-name" value="Player ${playerCount + 1}" maxlength="15">
                <button class="remove-player">✕</button>
            `;
            
            playerList.appendChild(playerItem);
            
            // Disable remove button if only 2 players
            this.updateRemoveButtons();
        }
    }
    
    /**
     * Update player color indicators
     */
    updatePlayerColors() {
        const playerItems = document.querySelectorAll('.player-item');
        playerItems.forEach((item, index) => {
            const colorDiv = item.querySelector('.player-color');
            colorDiv.style.backgroundColor = this.playerColors[index].primary;
        });
        
        // Update remove buttons state
        this.updateRemoveButtons();
    }
    
    /**
     * Update remove buttons state (disable if only 2 players)
     */
    updateRemoveButtons() {
        const playerItems = document.querySelectorAll('.player-item');
        const removeButtons = document.querySelectorAll('.remove-player');
        
        if (playerItems.length <= 2) {
            removeButtons.forEach(btn => btn.disabled = true);
        } else {
            removeButtons.forEach(btn => btn.disabled = false);
        }
    }
    
    /**
     * Start a multiplayer game
     */
    startMultiplayerGame() {
        // Get player names
        const playerInputs = document.querySelectorAll('.player-name');
        this.players = Array.from(playerInputs).map((input, index) => {
            return {
                name: input.value || `Player ${index + 1}`,
                score: 0,
                moves: 0,
                matches: 0,
                color: this.playerColors[index]
            };
        });
        
        // Close modal
        document.getElementById('multiplayerModal').style.display = 'none';
        
        // Set multiplayer active
        this.isMultiplayerActive = true;
        this.currentPlayerIndex = 0;
        
        // Start new game
        this.game.newGame();
        
        // Show scoreboard
        this.renderScoreboard();
        document.getElementById('playerScoreboard').style.display = 'flex';
        
        // Update game info display
        this.updateGameInfo();
        
        // Play sound
        if (window.soundEffects) {
            window.soundEffects.play('gameStart');
        }
    }
    
    /**
     * Render player scoreboard
     */
    renderScoreboard() {
        const scoreboard = document.getElementById('playerScoreboard');
        scoreboard.innerHTML = '';
        
        this.players.forEach((player, index) => {
            const playerCard = document.createElement('div');
            playerCard.className = `player-card ${index === this.currentPlayerIndex ? 'active' : ''}`;
            playerCard.style.borderColor = player.color.primary;
            
            playerCard.innerHTML = `
                <div class="player-name" style="color: ${player.color.primary};">${player.name}</div>
                <div class="player-stats">
                    <div class="player-score">Score: ${player.score}</div>
                    <div class="player-matches">Matches: ${player.matches}</div>
                </div>
            `;
            
            scoreboard.appendChild(playerCard);
        });
    }
    
    /**
     * Update game info display for current player
     */
    updateGameInfo() {
        const currentPlayer = this.players[this.currentPlayerIndex];
        
        // Update game info with current player
        const gameInfo = document.querySelector('.game-info');
        if (gameInfo) {
            const playerIndicator = document.getElementById('currentPlayer') || document.createElement('div');
            playerIndicator.id = 'currentPlayer';
            playerIndicator.style.color = currentPlayer.color.primary;
            playerIndicator.textContent = `Current: ${currentPlayer.name}`;
            
            if (!document.getElementById('currentPlayer')) {
                gameInfo.appendChild(playerIndicator);
            }
        }
    }
    
    /**
     * Handle card match event in multiplayer mode
     * @param {number} score - Points earned for the match
     */
    handleMatch(score) {
        if (!this.isMultiplayerActive) return;
        
        const currentPlayer = this.players[this.currentPlayerIndex];
        currentPlayer.score += score;
        currentPlayer.matches++;
        
        // Update scoreboard
        this.renderScoreboard();
        
        // In cooperative mode, don't change turns on match
        if (this.gameMode === 'competitive') {
            // Current player gets another turn on match
            // (no need to change currentPlayerIndex)
        }
    }
    
    /**
     * Handle card mismatch event in multiplayer mode
     */
    handleMismatch() {
        if (!this.isMultiplayerActive) return;
        
        // In competitive mode, change turns on mismatch
        if (this.gameMode === 'competitive') {
            this.nextPlayer();
        }
    }
    
    /**
     * Move to next player's turn
     */
    nextPlayer() {
        this.currentPlayerIndex = (this.currentPlayerIndex + 1) % this.players.length;
        
        // Update scoreboard
        this.renderScoreboard();
        
        // Update game info
        this.updateGameInfo();
        
        // Play sound
        if (window.soundEffects) {
            window.soundEffects.play('click');
        }
    }
    
    /**
     * Handle game completion in multiplayer mode
     * @returns {Object} Winner information
     */
    handleGameComplete() {
        if (!this.isMultiplayerActive) return null;
        
        let winner;
        
        if (this.gameMode === 'competitive') {
            // Find player with highest score
            winner = this.players.reduce((highest, player) => 
                player.score > highest.score ? player : highest, this.players[0]);
            
            // Check for tie
            const tie = this.players.filter(player => player.score === winner.score).length > 1;
            
            return {
                isMultiplayer: true,
                mode: this.gameMode,
                winner: tie ? null : winner,
                isTie: tie,
                players: this.players
            };
        } else {
            // In cooperative mode, all players win together
            return {
                isMultiplayer: true,
                mode: this.gameMode,
                winner: null,
                isTie: false,
                players: this.players,
                totalScore: this.players.reduce((sum, player) => sum + player.score, 0),
                totalMoves: this.players.reduce((sum, player) => sum + player.moves, 0)
            };
        }
    }
    
    /**
     * Reset multiplayer state
     */
    reset() {
        this.isMultiplayerActive = false;
        this.players = [];
        this.currentPlayerIndex = 0;
        
        // Hide scoreboard
        const scoreboard = document.getElementById('playerScoreboard');
        if (scoreboard) {
            scoreboard.style.display = 'none';
        }
        
        // Remove current player indicator
        const playerIndicator = document.getElementById('currentPlayer');
        if (playerIndicator) {
            playerIndicator.remove();
        }
    }
}

// Export multiplayer system
window.MultiplayerSystem = MultiplayerSystem;
