/**
 * Memory Match Challenge - Premium Particle Effects
 * Advanced particle systems for visual feedback and immersion
 */

class ParticleEffects {
    constructor() {
        this.particleSystems = {
            match: this.createMatchParticles,
            confetti: this.createConfetti,
            levelUp: this.createLevelUpParticles,
            achievement: this.createAchievementParticles,
            cardFlip: this.createCardFlipParticles
        };
        
        // Particle colors
        this.colors = {
            primary: ['#6366f1', '#818cf8', '#4f46e5'],
            secondary: ['#f59e0b', '#fbbf24', '#d97706'],
            success: ['#10b981', '#34d399', '#059669'],
            error: ['#ef4444', '#f87171', '#dc2626'],
            confetti: ['#6366f1', '#818cf8', '#4f46e5', '#f59e0b', '#fbbf24', '#10b981', '#ef4444']
        };
    }
    
    /**
     * Create match particles around matched cards
     * @param {HTMLElement} element1 - First card element
     * @param {HTMLElement} element2 - Second card element
     * @param {string} type - Type of match (normal, special, combo)
     */
    createMatchParticles(element1, element2, type = 'normal') {
        const count = type === 'normal' ? 20 : type === 'special' ? 30 : 40;
        const colorSet = type === 'normal' ? this.colors.primary : 
                        type === 'special' ? this.colors.secondary : this.colors.success;
        
        this.createElementParticles(element1, count, colorSet);
        this.createElementParticles(element2, count, colorSet);
    }
    
    /**
     * Create particles around an element
     * @param {HTMLElement} element - Source element
     * @param {number} count - Number of particles
     * @param {Array} colors - Array of colors
     */
    createElementParticles(element, count, colors) {
        if (!element) return;
        
        const rect = element.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        
        for (let i = 0; i < count; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            document.body.appendChild(particle);
            
            // Random position, size and color
            const size = Math.random() * 8 + 4;
            const color = colors[Math.floor(Math.random() * colors.length)];
            const shape = Math.random() > 0.5 ? '50%' : Math.random() > 0.5 ? '0' : '50% 0';
            
            gsap.set(particle, {
                x: centerX,
                y: centerY,
                width: size,
                height: size,
                backgroundColor: color,
                borderRadius: shape,
                position: 'fixed',
                zIndex: 1000
            });
            
            // Random direction and distance
            const angle = Math.random() * Math.PI * 2;
            const distance = Math.random() * 100 + 50;
            const destinationX = centerX + Math.cos(angle) * distance;
            const destinationY = centerY + Math.sin(angle) * distance;
            
            // Animate particle
            gsap.to(particle, {
                x: destinationX,
                y: destinationY,
                opacity: 0,
                rotation: Math.random() * 360,
                duration: Math.random() * 1 + 0.5,
                ease: "power2.out",
                onComplete: () => {
                    particle.remove();
                }
            });
        }
    }
    
    /**
     * Create confetti for celebrations
     * @param {number} count - Number of confetti particles
     */
    createConfetti(count = 150) {
        const colors = this.colors.confetti;
        
        for (let i = 0; i < count; i++) {
            const confetti = document.createElement('div');
            confetti.className = 'confetti';
            document.body.appendChild(confetti);
            
            // Random position, size, rotation and color
            const size = Math.random() * 10 + 5;
            const color = colors[Math.floor(Math.random() * colors.length)];
            const isRect = Math.random() > 0.5;
            const startX = Math.random() * window.innerWidth;
            const startRotation = Math.random() * 360;
            
            gsap.set(confetti, {
                x: startX,
                y: -100,
                width: size,
                height: isRect ? size : size * 0.4,
                backgroundColor: color,
                borderRadius: isRect ? '2px' : '50%',
                position: 'fixed',
                zIndex: 1000,
                rotation: startRotation
            });
            
            // Animate confetti
            gsap.to(confetti, {
                y: window.innerHeight + 100,
                rotation: startRotation + Math.random() * 360,
                x: startX + Math.sin(Math.random() * Math.PI * 2) * 200,
                duration: Math.random() * 3 + 2,
                ease: "power1.out",
                delay: Math.random() * 2,
                onComplete: () => {
                    confetti.remove();
                }
            });
        }
    }
    
    /**
     * Create level up celebration particles
     * @param {HTMLElement} element - Source element (level badge)
     */
    createLevelUpParticles(element) {
        if (!element) return;
        
        const rect = element.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        
        // Create burst particles
        for (let i = 0; i < 40; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            document.body.appendChild(particle);
            
            // Gold/yellow colors for level up
            const colors = ['#fbbf24', '#f59e0b', '#d97706', '#fcd34d'];
            const color = colors[Math.floor(Math.random() * colors.length)];
            const size = Math.random() * 8 + 4;
            
            gsap.set(particle, {
                x: centerX,
                y: centerY,
                width: size,
                height: size,
                backgroundColor: color,
                borderRadius: '50%',
                position: 'fixed',
                zIndex: 1000
            });
            
            // Burst outward in all directions
            const angle = Math.random() * Math.PI * 2;
            const distance = Math.random() * 150 + 50;
            const destinationX = centerX + Math.cos(angle) * distance;
            const destinationY = centerY + Math.sin(angle) * distance;
            
            // Animate with slight gravity effect
            gsap.to(particle, {
                x: destinationX,
                y: destinationY + 50, // Add slight gravity
                opacity: 0,
                rotation: Math.random() * 360,
                duration: Math.random() * 1.5 + 1,
                ease: "power2.out",
                onComplete: () => {
                    particle.remove();
                }
            });
        }
        
        // Create star particles that rise up
        for (let i = 0; i < 15; i++) {
            const star = document.createElement('div');
            star.className = 'particle';
            star.textContent = '★';
            document.body.appendChild(star);
            
            gsap.set(star, {
                x: centerX + (Math.random() * 60 - 30),
                y: centerY,
                fontSize: Math.random() * 15 + 10,
                color: '#fcd34d',
                position: 'fixed',
                zIndex: 1000
            });
            
            // Rise up with slight side-to-side movement
            gsap.to(star, {
                y: centerY - (Math.random() * 100 + 50),
                x: centerX + (Math.random() * 60 - 30),
                opacity: 0,
                duration: Math.random() * 2 + 1,
                ease: "power1.out",
                onComplete: () => {
                    star.remove();
                }
            });
        }
    }
    
    /**
     * Create achievement unlock particles
     * @param {HTMLElement} element - Achievement element
     */
    createAchievementParticles(element) {
        if (!element) return;
        
        const rect = element.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        
        // Create sparkle particles
        for (let i = 0; i < 30; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            document.body.appendChild(particle);
            
            // Purple/violet colors for achievements
            const colors = ['#8b5cf6', '#a78bfa', '#7c3aed', '#c4b5fd'];
            const color = colors[Math.floor(Math.random() * colors.length)];
            const size = Math.random() * 6 + 3;
            
            gsap.set(particle, {
                x: centerX + (Math.random() * rect.width - rect.width/2) * 0.8,
                y: centerY + (Math.random() * rect.height - rect.height/2) * 0.8,
                width: size,
                height: size,
                backgroundColor: color,
                borderRadius: '50%',
                position: 'fixed',
                zIndex: 1000,
                opacity: 0
            });
            
            // Sparkle effect (fade in and out)
            gsap.to(particle, {
                opacity: 1,
                duration: Math.random() * 0.5 + 0.2,
                yoyo: true,
                repeat: 1,
                ease: "power1.inOut",
                onComplete: () => {
                    particle.remove();
                }
            });
        }
        
        // Create trophy icon that rises
        const trophy = document.createElement('div');
        trophy.className = 'particle';
        trophy.textContent = '🏆';
        document.body.appendChild(trophy);
        
        gsap.set(trophy, {
            x: rect.right - 30,
            y: rect.bottom - 20,
            fontSize: '24px',
            position: 'fixed',
            zIndex: 1000,
            opacity: 0
        });
        
        // Rise up and fade out
        gsap.to(trophy, {
            y: rect.top - 30,
            opacity: 1,
            duration: 0.5,
            ease: "power1.out",
            onComplete: () => {
                gsap.to(trophy, {
                    opacity: 0,
                    delay: 0.5,
                    duration: 0.5,
                    onComplete: () => {
                        trophy.remove();
                    }
                });
            }
        });
    }
    
    /**
     * Create card flip particles
     * @param {HTMLElement} element - Card element
     */
    createCardFlipParticles(element) {
        if (!element) return;
        
        const rect = element.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        
        // Create small sparkles along the flip axis
        for (let i = 0; i < 10; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            document.body.appendChild(particle);
            
            // Blue colors for card flip
            const colors = ['#3b82f6', '#60a5fa', '#2563eb', '#93c5fd'];
            const color = colors[Math.floor(Math.random() * colors.length)];
            const size = Math.random() * 4 + 2;
            
            // Position along vertical center line
            const posY = rect.top + Math.random() * rect.height;
            
            gsap.set(particle, {
                x: centerX,
                y: posY,
                width: size,
                height: size,
                backgroundColor: color,
                borderRadius: '50%',
                position: 'fixed',
                zIndex: 1000,
                opacity: 0
            });
            
            // Sparkle and move slightly outward
            gsap.to(particle, {
                opacity: 1,
                x: centerX + (Math.random() * 20 - 10),
                duration: Math.random() * 0.3 + 0.2,
                ease: "power1.out",
                onComplete: () => {
                    gsap.to(particle, {
                        opacity: 0,
                        duration: Math.random() * 0.3 + 0.2,
                        onComplete: () => {
                            particle.remove();
                        }
                    });
                }
            });
        }
    }
}

// Export particle effects
window.ParticleEffects = ParticleEffects;
