/**
 * Memory Match Challenge - Performance Optimizations
 * Implementation of performance improvements and optimizations
 */

class PerformanceOptimizer {
    constructor() {
        this.animationFrameId = null;
        this.lastFrameTime = 0;
        this.fpsCounter = null;
        this.fpsValues = [];
        this.isMonitoring = false;
        this.debouncedEvents = {};
        this.throttledEvents = {};
        this.lazyLoadedImages = [];
        this.intersectionObserver = null;
    }
    
    /**
     * Initialize performance optimizer
     */
    init() {
        this.setupIntersectionObserver();
        this.setupEventOptimizations();
        this.optimizeAnimations();
    }
    
    /**
     * Setup Intersection Observer for lazy loading
     */
    setupIntersectionObserver() {
        // Create observer for lazy loading images
        this.intersectionObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const element = entry.target;
                    
                    // Handle lazy loading based on element type
                    if (element.dataset.lazySrc) {
                        element.src = element.dataset.lazySrc;
                        element.removeAttribute('data-lazy-src');
                        this.intersectionObserver.unobserve(element);
                    } else if (element.dataset.lazyBackground) {
                        element.style.backgroundImage = `url(${element.dataset.lazyBackground})`;
                        element.removeAttribute('data-lazy-background');
                        this.intersectionObserver.unobserve(element);
                    }
                }
            });
        }, {
            rootMargin: '100px',
            threshold: 0.1
        });
    }
    
    /**
     * Register an element for lazy loading
     * @param {HTMLElement} element - Element to lazy load
     * @param {string} src - Source URL
     * @param {boolean} isBackground - Whether to load as background image
     */
    registerLazyLoad(element, src, isBackground = false) {
        if (!element || !src) return;
        
        if (isBackground) {
            element.dataset.lazyBackground = src;
        } else {
            element.dataset.lazySrc = src;
        }
        
        this.lazyLoadedImages.push(element);
        this.intersectionObserver.observe(element);
    }
    
    /**
     * Setup event optimizations (debounce and throttle)
     */
    setupEventOptimizations() {
        // Optimize resize event
        this.setupWindowResizeOptimization();
        
        // Optimize scroll event
        this.setupScrollOptimization();
    }
    
    /**
     * Setup window resize optimization
     */
    setupWindowResizeOptimization() {
        // Original resize event handlers
        const originalHandlers = [];
        
        // Store original event listeners
        const originalAddEventListener = window.addEventListener;
        window.addEventListener = function(type, listener, options) {
            if (type === 'resize') {
                originalHandlers.push({ listener, options });
            } else {
                originalAddEventListener.call(window, type, listener, options);
            }
        };
        
        // Debounced resize handler
        const debouncedResize = this.debounce(() => {
            originalHandlers.forEach(handler => {
                handler.listener.call(window, new Event('resize'));
            });
        }, 150);
        
        // Add single debounced handler
        originalAddEventListener.call(window, 'resize', debouncedResize);
        
        // Restore original method
        window.addEventListener = originalAddEventListener;
    }
    
    /**
     * Setup scroll optimization
     */
    setupScrollOptimization() {
        // Use passive event listeners for scroll events
        document.addEventListener('scroll', () => {}, { passive: true });
        
        // Throttle scroll-based animations
        const scrollElements = document.querySelectorAll('.scroll-animate');
        
        if (scrollElements.length > 0) {
            const throttledScroll = this.throttle(() => {
                this.handleScrollAnimations(scrollElements);
            }, 100);
            
            document.addEventListener('scroll', throttledScroll, { passive: true });
        }
    }
    
    /**
     * Handle scroll-based animations
     * @param {NodeList} elements - Elements to animate on scroll
     */
    handleScrollAnimations(elements) {
        elements.forEach(element => {
            const rect = element.getBoundingClientRect();
            const isVisible = (
                rect.top <= window.innerHeight && 
                rect.bottom >= 0
            );
            
            if (isVisible && !element.classList.contains('animated')) {
                element.classList.add('animated');
            }
        });
    }
    
    /**
     * Optimize animations
     */
    optimizeAnimations() {
        // Use requestAnimationFrame for animations
        const animateElements = document.querySelectorAll('.animate');
        
        if (animateElements.length > 0) {
            let lastTimestamp = 0;
            
            const animate = (timestamp) => {
                // Limit to 60fps (approximately 16.7ms per frame)
                if (timestamp - lastTimestamp >= 16) {
                    lastTimestamp = timestamp;
                    
                    animateElements.forEach(element => {
                        // Apply animation logic
                        this.updateElementAnimation(element, timestamp);
                    });
                }
                
                this.animationFrameId = requestAnimationFrame(animate);
            };
            
            this.animationFrameId = requestAnimationFrame(animate);
        }
    }
    
    /**
     * Update element animation
     * @param {HTMLElement} element - Element to animate
     * @param {number} timestamp - Animation timestamp
     */
    updateElementAnimation(element, timestamp) {
        // Example animation logic
        if (element.dataset.animationType === 'pulse') {
            const scale = 1 + 0.05 * Math.sin(timestamp / 500);
            element.style.transform = `scale(${scale})`;
        } else if (element.dataset.animationType === 'rotate') {
            const rotation = (timestamp / 20) % 360;
            element.style.transform = `rotate(${rotation}deg)`;
        }
    }
    
    /**
     * Clean up animations
     */
    cleanupAnimations() {
        if (this.animationFrameId) {
            cancelAnimationFrame(this.animationFrameId);
            this.animationFrameId = null;
        }
    }
    
    /**
     * Start FPS monitoring
     */
    startFPSMonitoring() {
        if (this.isMonitoring) return;
        
        this.isMonitoring = true;
        this.fpsValues = [];
        this.lastFrameTime = performance.now();
        
        // Create FPS counter element if it doesn't exist
        if (!this.fpsCounter) {
            this.fpsCounter = document.createElement('div');
            this.fpsCounter.className = 'fps-counter';
            this.fpsCounter.style.position = 'fixed';
            this.fpsCounter.style.top = '10px';
            this.fpsCounter.style.right = '10px';
            this.fpsCounter.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
            this.fpsCounter.style.color = 'white';
            this.fpsCounter.style.padding = '5px 10px';
            this.fpsCounter.style.borderRadius = '5px';
            this.fpsCounter.style.fontSize = '14px';
            this.fpsCounter.style.zIndex = '9999';
            document.body.appendChild(this.fpsCounter);
        }
        
        this.fpsCounter.style.display = 'block';
        
        const updateFPS = () => {
            if (!this.isMonitoring) return;
            
            const now = performance.now();
            const delta = now - this.lastFrameTime;
            this.lastFrameTime = now;
            
            const fps = 1000 / delta;
            this.fpsValues.push(fps);
            
            // Keep only last 60 values
            if (this.fpsValues.length > 60) {
                this.fpsValues.shift();
            }
            
            // Calculate average FPS
            const avgFps = this.fpsValues.reduce((sum, value) => sum + value, 0) / this.fpsValues.length;
            
            // Update counter
            this.fpsCounter.textContent = `FPS: ${Math.round(avgFps)}`;
            
            requestAnimationFrame(updateFPS);
        };
        
        requestAnimationFrame(updateFPS);
    }
    
    /**
     * Stop FPS monitoring
     */
    stopFPSMonitoring() {
        this.isMonitoring = false;
        
        if (this.fpsCounter) {
            this.fpsCounter.style.display = 'none';
        }
    }
    
    /**
     * Create a debounced function
     * @param {Function} func - Function to debounce
     * @param {number} wait - Wait time in milliseconds
     * @returns {Function} Debounced function
     */
    debounce(func, wait) {
        let timeout;
        
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    /**
     * Create a throttled function
     * @param {Function} func - Function to throttle
     * @param {number} limit - Limit in milliseconds
     * @returns {Function} Throttled function
     */
    throttle(func, limit) {
        let inThrottle;
        
        return function executedFunction(...args) {
            if (!inThrottle) {
                func(...args);
                inThrottle = true;
                
                setTimeout(() => {
                    inThrottle = false;
                }, limit);
            }
        };
    }
    
    /**
     * Optimize images on the page
     */
    optimizeImages() {
        // Find all images
        const images = document.querySelectorAll('img:not([data-lazy-src])');
        
        images.forEach(img => {
            // Register for lazy loading if not in viewport
            const rect = img.getBoundingClientRect();
            const isInViewport = (
                rect.top <= window.innerHeight && 
                rect.bottom >= 0
            );
            
            if (!isInViewport && img.src) {
                const originalSrc = img.src;
                img.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1 1"%3E%3C/svg%3E';
                this.registerLazyLoad(img, originalSrc);
            }
        });
        
        // Find elements with background images
        const elementsWithBgImage = document.querySelectorAll('[style*="background-image"]');
        
        elementsWithBgImage.forEach(element => {
            const style = window.getComputedStyle(element);
            const bgImage = style.backgroundImage;
            
            if (bgImage && bgImage !== 'none' && !element.dataset.lazyBackground) {
                const rect = element.getBoundingClientRect();
                const isInViewport = (
                    rect.top <= window.innerHeight && 
                    rect.bottom >= 0
                );
                
                if (!isInViewport) {
                    const match = bgImage.match(/url\(['"]?(.*?)['"]?\)/);
                    if (match && match[1]) {
                        const originalSrc = match[1];
                        element.style.backgroundImage = 'none';
                        this.registerLazyLoad(element, originalSrc, true);
                    }
                }
            }
        });
    }
    
    /**
     * Apply memory optimizations
     */
    applyMemoryOptimizations() {
        // Clean up unused DOM elements
        this.cleanupUnusedElements();
        
        // Optimize event listeners
        this.optimizeEventListeners();
        
        // Suggest garbage collection
        if (window.gc) {
            window.gc();
        }
    }
    
    /**
     * Clean up unused DOM elements
     */
    cleanupUnusedElements() {
        // Remove hidden modals from DOM
        const hiddenModals = document.querySelectorAll('.modal[style*="display: none"]');
        hiddenModals.forEach(modal => {
            // Store in document fragment instead of removing completely
            const fragment = document.createDocumentFragment();
            fragment.appendChild(modal);
            
            // Add function to restore modal when needed
            window.restoreModal = function(modalId) {
                const modal = fragment.querySelector(`#${modalId}`);
                if (modal) {
                    document.body.appendChild(modal);
                }
            };
        });
    }
    
    /**
     * Optimize event listeners
     */
    optimizeEventListeners() {
        // Use event delegation for common events
        document.addEventListener('click', (e) => {
            // Handle card clicks
            if (e.target.closest('.card')) {
                const card = e.target.closest('.card');
                // Dispatch custom event for the specific card
                const cardEvent = new CustomEvent('cardClick', { detail: { cardId: card.dataset.id } });
                document.dispatchEvent(cardEvent);
            }
            
            // Handle button clicks
            if (e.target.closest('button')) {
                const button = e.target.closest('button');
                // Dispatch custom event for the specific button
                const buttonEvent = new CustomEvent('buttonClick', { detail: { buttonId: button.id } });
                document.dispatchEvent(buttonEvent);
            }
        });
    }
    
    /**
     * Apply CSS optimizations
     */
    applyCSSOptimizations() {
        // Create a style element for critical CSS
        const criticalCss = document.createElement('style');
        criticalCss.textContent = `
            /* Critical CSS for above-the-fold content */
            body, html {
                margin: 0;
                padding: 0;
                height: 100%;
            }
            .container {
                max-width: 1200px;
                margin: 0 auto;
                padding: 20px;
            }
            .game-board {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
                gap: 10px;
                margin: 20px 0;
            }
            .card {
                aspect-ratio: 3/4;
                perspective: 1000px;
                cursor: pointer;
            }
            .card-inner {
                position: relative;
                width: 100%;
                height: 100%;
                transform-style: preserve-3d;
                transition: transform 0.6s;
            }
            .card-front, .card-back {
                position: absolute;
                width: 100%;
                height: 100%;
                backface-visibility: hidden;
                border-radius: 10px;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .card-front {
                transform: rotateY(180deg);
            }
            .card.flipped .card-inner {
                transform: rotateY(180deg);
            }
        `;
        
        // Insert at the top of the head
        document.head.insertBefore(criticalCss, document.head.firstChild);
        
        // Add will-change property to animated elements
        const animatedElements = document.querySelectorAll('.card-inner, .animate');
        animatedElements.forEach(element => {
            element.style.willChange = 'transform';
        });
        
        // Remove will-change after animation completes
        document.addEventListener('transitionend', (e) => {
            if (e.target.classList.contains('card-inner')) {
                e.target.style.willChange = 'auto';
                
                // Re-add will-change when needed
                setTimeout(() => {
                    e.target.style.willChange = 'transform';
                }, 200);
            }
        });
    }
    
    /**
     * Apply responsive optimizations
     */
    applyResponsiveOptimizations() {
        // Add viewport meta tag if not present
        if (!document.querySelector('meta[name="viewport"]')) {
            const viewport = document.createElement('meta');
            viewport.name = 'viewport';
            viewport.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
            document.head.appendChild(viewport);
        }
        
        // Add media queries for different device sizes
        const responsiveStyles = document.createElement('style');
        responsiveStyles.textContent = `
            /* Mobile devices */
            @media (max-width: 480px) {
                .game-board {
                    grid-template-columns: repeat(4, 1fr);
                    gap: 5px;
                }
                .card {
                    aspect-ratio: 2/3;
                }
                .card-front {
                    font-size: 1.5rem;
                }
                .controls button {
                    padding: 8px 12px;
                    font-size: 0.9rem;
                }
                .modal-content {
                    width: 90%;
                    padding: 15px;
                }
            }
            
            /* Tablets */
            @media (min-width: 481px) and (max-width: 768px) {
                .game-board {
                    grid-template-columns: repeat(5, 1fr);
                    gap: 8px;
                }
                .controls {
                    flex-wrap: wrap;
                }
            }
            
            /* Laptops and desktops */
            @media (min-width: 769px) {
                .game-board {
                    grid-template-columns: repeat(6, 1fr);
                    gap: 10px;
                }
            }
            
            /* Large screens */
            @media (min-width: 1200px) {
                .game-board {
                    grid-template-columns: repeat(8, 1fr);
                    gap: 15px;
                }
            }
            
            /* High-DPI screens */
            @media (-webkit-min-device-pixel-ratio: 2), (min-resolution: 192dpi) {
                .card-back, .card-front {
                    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                }
            }
            
            /* Dark mode */
            @media (prefers-color-scheme: dark) {
                body:not(.light-theme) {
                    background-color: #121212;
                    color: #f5f5f5;
                }
            }
            
            /* Reduced motion */
            @media (prefers-reduced-motion: reduce) {
                .card-inner {
                    transition: transform 0.2s;
                }
                .animate {
                    animation: none !important;
                    transition: none !important;
                }
            }
        `;
        
        document.head.appendChild(responsiveStyles);
        
        // Add touch event handling for mobile devices
        if ('ontouchstart' in window) {
            document.addEventListener('touchstart', () => {}, { passive: true });
        }
    }
}

// Export performance optimizer
window.PerformanceOptimizer = PerformanceOptimizer;
