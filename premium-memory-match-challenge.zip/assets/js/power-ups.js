/**
 * Memory Match Challenge - Power-ups System
 * Implementation of power-ups and abilities
 */

class PowerUpsSystem {
    constructor(gameInstance) {
        this.game = gameInstance;
        
        // Available power-ups
        this.powerUps = [
            {
                id: 'hint',
                name: 'Hint',
                description: 'Reveals a matching pair briefly',
                icon: '💡',
                cost: 50,
                cooldown: 30, // seconds
                effect: this.hintEffect.bind(this)
            },
            {
                id: 'timeBoost',
                name: 'Time Boost',
                description: 'Adds 15 seconds in Time Attack mode or reduces time by 10 seconds in Classic mode',
                icon: '⏱️',
                cost: 75,
                cooldown: 45,
                effect: this.timeBoostEffect.bind(this)
            },
            {
                id: 'doublePoints',
                name: 'Double Points',
                description: 'Doubles points earned for the next 3 matches',
                icon: '✨',
                cost: 100,
                cooldown: 60,
                effect: this.doublePointsEffect.bind(this)
            },
            {
                id: 'revealAll',
                name: 'Reveal All',
                description: 'Reveals all cards for 2 seconds',
                icon: '👁️',
                cost: 150,
                cooldown: 90,
                effect: this.revealAllEffect.bind(this)
            },
            {
                id: 'matchFinder',
                name: 'Match Finder',
                description: 'Automatically matches one pair',
                icon: '🔍',
                cost: 200,
                cooldown: 120,
                effect: this.matchFinderEffect.bind(this)
            }
        ];
        
        // Player's power-up inventory
        this.inventory = {
            points: 0,
            activePowerUps: [],
            cooldowns: {}
        };
        
        // Double points effect tracking
        this.doublePointsActive = false;
        this.doublePointsMatchesLeft = 0;
    }
    
    /**
     * Initialize power-ups system
     */
    init() {
        this.loadInventory();
        this.renderPowerUps();
        this.setupEventListeners();
    }
    
    /**
     * Load player's inventory from localStorage
     */
    loadInventory() {
        const savedInventory = localStorage.getItem('memoryGamePowerUps');
        if (savedInventory) {
            this.inventory = JSON.parse(savedInventory);
        } else {
            // Default starting points
            this.inventory = {
                points: 100, // Starting with some points
                activePowerUps: [],
                cooldowns: {}
            };
            this.saveInventory();
        }
    }
    
    /**
     * Save player's inventory to localStorage
     */
    saveInventory() {
        localStorage.setItem('memoryGamePowerUps', JSON.stringify(this.inventory));
    }
    
    /**
     * Render power-ups UI
     */
    renderPowerUps() {
        const powerUpsContainer = document.getElementById('powerUpsContainer');
        if (!powerUpsContainer) return;
        
        powerUpsContainer.innerHTML = '';
        
        // Add points display
        const pointsDisplay = document.createElement('div');
        pointsDisplay.className = 'power-up-points';
        pointsDisplay.innerHTML = `<span>${this.inventory.points}</span> <span class="power-up-icon">⚡</span>`;
        powerUpsContainer.appendChild(pointsDisplay);
        
        // Add power-ups
        this.powerUps.forEach(powerUp => {
            const powerUpElement = document.createElement('button');
            powerUpElement.className = 'power-up-button';
            powerUpElement.dataset.id = powerUp.id;
            
            // Check if on cooldown
            const onCooldown = this.isOnCooldown(powerUp.id);
            const canAfford = this.inventory.points >= powerUp.cost;
            
            if (onCooldown) {
                powerUpElement.classList.add('cooldown');
                const cooldownLeft = this.getCooldownLeft(powerUp.id);
                powerUpElement.innerHTML = `
                    <span class="power-up-icon">${powerUp.icon}</span>
                    <span class="cooldown-timer">${cooldownLeft}s</span>
                `;
            } else if (!canAfford) {
                powerUpElement.classList.add('disabled');
                powerUpElement.innerHTML = `
                    <span class="power-up-icon">${powerUp.icon}</span>
                    <span class="power-up-cost">${powerUp.cost}</span>
                `;
            } else {
                powerUpElement.innerHTML = `
                    <span class="power-up-icon">${powerUp.icon}</span>
                    <span class="power-up-cost">${powerUp.cost}</span>
                `;
            }
            
            // Add tooltip
            powerUpElement.title = `${powerUp.name}: ${powerUp.description} (Cost: ${powerUp.cost})`;
            
            powerUpsContainer.appendChild(powerUpElement);
        });
    }
    
    /**
     * Setup event listeners for power-up buttons
     */
    setupEventListeners() {
        document.addEventListener('click', (event) => {
            if (event.target.closest('.power-up-button')) {
                const button = event.target.closest('.power-up-button');
                const powerUpId = button.dataset.id;
                this.usePowerUp(powerUpId);
            }
        });
    }
    
    /**
     * Check if a power-up is on cooldown
     * @param {string} powerUpId - Power-up ID
     * @returns {boolean} Whether the power-up is on cooldown
     */
    isOnCooldown(powerUpId) {
        if (!this.inventory.cooldowns[powerUpId]) return false;
        return this.inventory.cooldowns[powerUpId] > Date.now();
    }
    
    /**
     * Get cooldown time left in seconds
     * @param {string} powerUpId - Power-up ID
     * @returns {number} Cooldown time left in seconds
     */
    getCooldownLeft(powerUpId) {
        if (!this.inventory.cooldowns[powerUpId]) return 0;
        const timeLeft = Math.max(0, this.inventory.cooldowns[powerUpId] - Date.now());
        return Math.ceil(timeLeft / 1000);
    }
    
    /**
     * Use a power-up
     * @param {string} powerUpId - Power-up ID
     */
    usePowerUp(powerUpId) {
        // Find the power-up
        const powerUp = this.powerUps.find(p => p.id === powerUpId);
        if (!powerUp) return;
        
        // Check if on cooldown
        if (this.isOnCooldown(powerUpId)) {
            this.showMessage(`${powerUp.name} is on cooldown!`);
            return;
        }
        
        // Check if player can afford it
        if (this.inventory.points < powerUp.cost) {
            this.showMessage(`Not enough points for ${powerUp.name}!`);
            return;
        }
        
        // Deduct points
        this.inventory.points -= powerUp.cost;
        
        // Set cooldown
        this.inventory.cooldowns[powerUpId] = Date.now() + (powerUp.cooldown * 1000);
        
        // Save inventory
        this.saveInventory();
        
        // Apply effect
        powerUp.effect();
        
        // Update UI
        this.renderPowerUps();
        
        // Show message
        this.showMessage(`${powerUp.name} activated!`);
    }
    
    /**
     * Award points to the player
     * @param {number} points - Points to award
     */
    awardPoints(points) {
        this.inventory.points += points;
        this.saveInventory();
        this.renderPowerUps();
    }
    
    /**
     * Show a message to the player
     * @param {string} message - Message to show
     */
    showMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'power-up-message';
        messageElement.textContent = message;
        document.body.appendChild(messageElement);
        
        // Animate and remove
        setTimeout(() => {
            messageElement.style.opacity = '1';
            messageElement.style.transform = 'translateY(0)';
            
            setTimeout(() => {
                messageElement.style.opacity = '0';
                messageElement.style.transform = 'translateY(-20px)';
                
                setTimeout(() => {
                    messageElement.remove();
                }, 500);
            }, 2000);
        }, 10);
    }
    
    /**
     * Hint effect - reveals a matching pair briefly
     */
    hintEffect() {
        // Find an unmatched pair
        const unmatchedCards = this.game.cards.filter(card => !card.isMatched && !card.isFlipped);
        if (unmatchedCards.length < 2) return;
        
        // Find a matching pair
        const pairs = {};
        unmatchedCards.forEach(card => {
            if (!pairs[card.emoji]) {
                pairs[card.emoji] = [card];
            } else {
                pairs[card.emoji].push(card);
            }
        });
        
        // Filter pairs that have exactly 2 cards
        const validPairs = Object.values(pairs).filter(pair => pair.length === 2);
        if (validPairs.length === 0) return;
        
        // Select a random pair
        const randomPair = validPairs[Math.floor(Math.random() * validPairs.length)];
        const [card1, card2] = randomPair;
        
        // Temporarily flip the cards
        card1.isFlipped = true;
        card2.isFlipped = true;
        this.game.renderCards();
        
        // Add highlight effect
        const card1Element = document.querySelector(`.card[data-id="${card1.id}"]`);
        const card2Element = document.querySelector(`.card[data-id="${card2.id}"]`);
        
        if (card1Element && card2Element) {
            card1Element.classList.add('hint-highlight');
            card2Element.classList.add('hint-highlight');
        }
        
        // Flip them back after a delay
        setTimeout(() => {
            card1.isFlipped = false;
            card2.isFlipped = false;
            this.game.renderCards();
        }, 2000);
    }
    
    /**
     * Time boost effect - adds or reduces time
     */
    timeBoostEffect() {
        if (this.game.gameMode === 'timeAttack') {
            // Add time in time attack mode
            this.game.seconds += 15;
            this.showTimeAnimation(15, true);
        } else if (this.game.gameMode === 'classic') {
            // Reduce time in classic mode
            this.game.seconds = Math.max(0, this.game.seconds - 10);
            this.showTimeAnimation(10, false);
        }
        
        // Update game info
        this.game.updateGameInfo();
    }
    
    /**
     * Double points effect - doubles points for next 3 matches
     */
    doublePointsEffect() {
        this.doublePointsActive = true;
        this.doublePointsMatchesLeft = 3;
        
        // Add visual indicator
        const scoreElement = document.getElementById('score');
        if (scoreElement) {
            scoreElement.classList.add('double-points-active');
        }
        
        // Show message
        this.showMessage('Double points active for next 3 matches!');
    }
    
    /**
     * Apply double points if active
     * @param {number} points - Base points
     * @returns {number} Modified points
     */
    modifyPoints(points) {
        if (!this.doublePointsActive) return points;
        
        // Double the points
        const modifiedPoints = points * 2;
        
        // Decrement matches left
        this.doublePointsMatchesLeft--;
        
        // Check if effect has ended
        if (this.doublePointsMatchesLeft <= 0) {
            this.doublePointsActive = false;
            
            // Remove visual indicator
            const scoreElement = document.getElementById('score');
            if (scoreElement) {
                scoreElement.classList.remove('double-points-active');
            }
            
            // Show message
            this.showMessage('Double points effect ended');
        }
        
        return modifiedPoints;
    }
    
    /**
     * Reveal all effect - reveals all cards briefly
     */
    revealAllEffect() {
        // Create a flash effect
        const flash = document.createElement('div');
        flash.className = 'flash-effect';
        document.body.appendChild(flash);
        
        setTimeout(() => {
            flash.remove();
            
            // Flip all unmatched cards
            const unmatched = this.game.cards.filter(c => !c.isMatched);
            unmatched.forEach(c => {
                c.isFlipped = true;
            });
            this.game.renderCards();
            
            // Flip them back after a delay
            setTimeout(() => {
                unmatched.forEach(c => {
                    if (!c.isFrozen) { // Don't flip back frozen cards
                        c.isFlipped = false;
                    }
                });
                
                // Keep currently flipped cards flipped
                this.game.flippedCards.forEach(c => {
                    c.isFlipped = true;
                });
                
                this.game.renderCards();
            }, 2000);
        }, 300);
    }
    
    /**
     * Match finder effect - automatically matches one pair
     */
    matchFinderEffect() {
        // Find an unmatched pair
        const unmatchedCards = this.game.cards.filter(card => !card.isMatched && !card.isFlipped);
        if (unmatchedCards.length < 2) return;
        
        // Find a matching pair
        const pairs = {};
        unmatchedCards.forEach(card => {
            if (!pairs[card.emoji]) {
                pairs[card.emoji] = [card];
            } else {
                pairs[card.emoji].push(card);
            }
        });
        
        // Filter pairs that have exactly 2 cards
        const validPairs = Object.values(pairs).filter(pair => pair.length === 2);
        if (validPairs.length === 0) return;
        
        // Select a random pair
        const randomPair = validPairs[Math.floor(Math.random() * validPairs.length)];
        const [card1, card2] = randomPair;
        
        // Match the cards
        card1.isFlipped = true;
        card2.isFlipped = true;
        card1.isMatched = true;
        card2.isMatched = true;
        
        // Update game state
        this.game.matchedPairs++;
        
        // Award points
        const basePoints = 10 * this.game.getDifficultyMultiplier();
        this.game.score += basePoints;
        
        // Update game info
        this.game.updateGameInfo();
        
        // Render cards
        this.game.renderCards();
        
        // Show match animation
        const card1Element = document.querySelector(`.card[data-id="${card1.id}"]`);
        const card2Element = document.querySelector(`.card[data-id="${card2.id}"]`);
        
        if (this.game.animationController && card1Element && card2Element) {
            this.game.animationController.cardMatchAnimation(card1Element, card2Element);
        }
        
        // Check if game is complete
        if (this.game.matchedPairs === this.game.totalPairs) {
            this.game.endGame();
        }
    }
    
    /**
     * Show time animation
     * @param {number} time - Time amount
     * @param {boolean} isBonus - Whether it's a bonus (true) or reduction (false)
     */
    showTimeAnimation(time, isBonus) {
        const timerElement = document.getElementById('timer');
        if (!timerElement) return;
        
        const rect = timerElement.getBoundingClientRect();
        const timeElement = document.createElement('div');
        timeElement.className = 'time-animation';
        timeElement.textContent = isBonus ? `+${time}s` : `-${time}s`;
        timeElement.style.color = isBonus ? '#10b981' : '#ef4444';
        timeElement.style.left = `${rect.left + rect.width / 2}px`;
        timeElement.style.top = `${rect.top}px`;
        document.body.appendChild(timeElement);
        
        // Animate and remove
        setTimeout(() => {
            timeElement.style.transform = 'translateY(-30px)';
            timeElement.style.opacity = '0';
            
            setTimeout(() => {
                timeElement.remove();
            }, 1000);
        }, 10);
    }
}

// Export power-ups system
window.PowerUpsSystem = PowerUpsSystem;
