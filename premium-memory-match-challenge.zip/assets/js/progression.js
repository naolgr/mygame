/**
 * Memory Match Challenge - Progression System
 * Implementation of player levels, achievements, and rewards
 */

class ProgressionSystem {
    constructor(gameInstance) {
        this.game = gameInstance;
        
        // Player progression data
        this.playerData = {
            level: 1,
            experience: 0,
            totalGamesPlayed: 0,
            achievements: [],
            unlockedThemes: ['default'],
            unlockedCardBacks: ['default'],
            dailyChallenge: {
                lastUpdated: null,
                current: null,
                completed: false
            }
        };
        
        // Experience required for each level
        this.levelRequirements = [
            0,      // Level 1
            100,    // Level 2
            250,    // Level 3
            500,    // Level 4
            1000,   // Level 5
            1750,   // Level 6
            3000,   // Level 7
            5000,   // Level 8
            8000,   // Level 9
            12000   // Level 10
        ];
        
        // Available achievements
        this.achievements = [
            {
                id: 'first_win',
                name: 'First Victory',
                description: 'Complete your first game',
                icon: '🏆',
                experienceReward: 50,
                condition: (stats) => stats.gamesCompleted >= 1,
                achieved: false
            },
            {
                id: 'speed_demon',
                name: 'Speed Demon',
                description: 'Complete a game in under 30 seconds',
                icon: '⚡',
                experienceReward: 100,
                condition: (stats) => stats.fastestTime <= 30,
                achieved: false
            },
            {
                id: 'perfect_memory',
                name: 'Perfect Memory',
                description: 'Complete a game with minimum possible moves',
                icon: '🧠',
                experienceReward: 150,
                condition: (stats) => stats.perfectGames >= 1,
                achieved: false
            },
            {
                id: 'combo_master',
                name: 'Combo Master',
                description: 'Achieve a 5x combo',
                icon: '🔥',
                experienceReward: 100,
                condition: (stats) => stats.highestCombo >= 5,
                achieved: false
            },
            {
                id: 'expert_challenge',
                name: 'Expert Challenger',
                description: 'Complete a game on Expert difficulty',
                icon: '🌟',
                experienceReward: 200,
                condition: (stats) => stats.expertGamesCompleted >= 1,
                achieved: false
            },
            {
                id: 'time_attack_survivor',
                name: 'Time Attack Survivor',
                description: 'Score over 300 points in Time Attack mode',
                icon: '⏱️',
                experienceReward: 150,
                condition: (stats) => stats.highestTimeAttackScore >= 300,
                achieved: false
            },
            {
                id: 'zen_master',
                name: 'Zen Master',
                description: 'Complete 5 games in Zen mode',
                icon: '🧘',
                experienceReward: 100,
                condition: (stats) => stats.zenGamesCompleted >= 5,
                achieved: false
            },
            {
                id: 'special_finder',
                name: 'Special Finder',
                description: 'Match 10 special cards',
                icon: '🃏',
                experienceReward: 150,
                condition: (stats) => stats.specialCardsMatched >= 10,
                achieved: false
            },
            {
                id: 'dedicated_player',
                name: 'Dedicated Player',
                description: 'Play 20 games',
                icon: '🎮',
                experienceReward: 200,
                condition: (stats) => stats.gamesPlayed >= 20,
                achieved: false
            },
            {
                id: 'daily_challenger',
                name: 'Daily Challenger',
                description: 'Complete 5 daily challenges',
                icon: '📅',
                experienceReward: 250,
                condition: (stats) => stats.dailyChallengesCompleted >= 5,
                achieved: false
            }
        ];
        
        // Available themes (unlocked at different levels)
        this.themes = [
            {
                id: 'default',
                name: 'Classic',
                description: 'The classic memory match theme',
                levelRequired: 1,
                cssVariables: {} // Default theme uses base CSS variables
            },
            {
                id: 'neon',
                name: 'Neon',
                description: 'A vibrant neon theme',
                levelRequired: 2,
                cssVariables: {
                    '--primary-color': '#ff00ff',
                    '--primary-light': '#ff66ff',
                    '--primary-dark': '#cc00cc',
                    '--secondary-color': '#00ffff',
                    '--secondary-light': '#66ffff',
                    '--secondary-dark': '#00cccc',
                    '--card-back-gradient-1': '#ff00ff',
                    '--card-back-gradient-2': '#00ffff'
                }
            },
            {
                id: 'dark',
                name: 'Dark Elegance',
                description: 'A sophisticated dark theme',
                levelRequired: 3,
                cssVariables: {
                    '--primary-color': '#9333ea',
                    '--primary-light': '#a855f7',
                    '--primary-dark': '#7e22ce',
                    '--secondary-color': '#ec4899',
                    '--secondary-light': '#f472b6',
                    '--secondary-dark': '#db2777',
                    '--background-color': '#18181b',
                    '--text-color': '#f4f4f5',
                    '--card-back-gradient-1': '#9333ea',
                    '--card-back-gradient-2': '#4c1d95'
                }
            },
            {
                id: 'nature',
                name: 'Natural',
                description: 'A calming nature-inspired theme',
                levelRequired: 4,
                cssVariables: {
                    '--primary-color': '#16a34a',
                    '--primary-light': '#22c55e',
                    '--primary-dark': '#15803d',
                    '--secondary-color': '#ca8a04',
                    '--secondary-light': '#eab308',
                    '--secondary-dark': '#a16207',
                    '--background-color': '#f0fdf4',
                    '--text-color': '#166534',
                    '--card-back-gradient-1': '#16a34a',
                    '--card-back-gradient-2': '#15803d'
                }
            },
            {
                id: 'ocean',
                name: 'Ocean Depths',
                description: 'A deep blue ocean theme',
                levelRequired: 5,
                cssVariables: {
                    '--primary-color': '#0284c7',
                    '--primary-light': '#0ea5e9',
                    '--primary-dark': '#0369a1',
                    '--secondary-color': '#06b6d4',
                    '--secondary-light': '#22d3ee',
                    '--secondary-dark': '#0891b2',
                    '--background-color': '#ecfeff',
                    '--text-color': '#0c4a6e',
                    '--card-back-gradient-1': '#0284c7',
                    '--card-back-gradient-2': '#0c4a6e'
                }
            }
        ];
        
        // Available card backs (unlocked through achievements)
        this.cardBacks = [
            {
                id: 'default',
                name: 'Classic',
                description: 'The classic card back design',
                unlockedBy: null, // Available by default
                cssClass: ''
            },
            {
                id: 'geometric',
                name: 'Geometric',
                description: 'A modern geometric pattern',
                unlockedBy: 'first_win',
                cssClass: 'card-back-geometric'
            },
            {
                id: 'stars',
                name: 'Starry',
                description: 'A beautiful starry pattern',
                unlockedBy: 'speed_demon',
                cssClass: 'card-back-stars'
            },
            {
                id: 'gradient',
                name: 'Gradient',
                description: 'A smooth color gradient',
                unlockedBy: 'perfect_memory',
                cssClass: 'card-back-gradient'
            },
            {
                id: 'circuit',
                name: 'Circuit',
                description: 'A tech-inspired circuit pattern',
                unlockedBy: 'expert_challenge',
                cssClass: 'card-back-circuit'
            }
        ];
        
        // Daily challenge templates
        this.dailyChallengeTemplates = [
            {
                id: 'quick_match',
                name: 'Quick Match',
                description: 'Complete a game in under 45 seconds',
                checkCompletion: (gameStats) => gameStats.time <= 45,
                experienceReward: 100
            },
            {
                id: 'efficient_solver',
                name: 'Efficient Solver',
                description: 'Complete a Medium difficulty game in 12 moves or less',
                checkCompletion: (gameStats) => gameStats.difficulty === 'medium' && gameStats.moves <= 12,
                experienceReward: 150
            },
            {
                id: 'combo_challenge',
                name: 'Combo Challenge',
                description: 'Achieve a 3x combo or higher',
                checkCompletion: (gameStats) => gameStats.highestCombo >= 3,
                experienceReward: 100
            },
            {
                id: 'time_attack_challenge',
                name: 'Time Attack Challenge',
                description: 'Score at least 200 points in Time Attack mode',
                checkCompletion: (gameStats) => gameStats.gameMode === 'timeAttack' && gameStats.score >= 200,
                experienceReward: 150
            },
            {
                id: 'hard_victory',
                name: 'Hard Victory',
                description: 'Complete a game on Hard difficulty',
                checkCompletion: (gameStats) => gameStats.difficulty === 'hard',
                experienceReward: 125
            }
        ];
    }
    
    /**
     * Initialize progression system
     */
    init() {
        this.loadPlayerData();
        this.checkDailyChallenge();
        this.renderProgressionUI();
        this.applyTheme();
        this.applyCardBack();
    }
    
    /**
     * Load player data from localStorage
     */
    loadPlayerData() {
        const savedData = localStorage.getItem('memoryGameProgression');
        if (savedData) {
            this.playerData = JSON.parse(savedData);
            
            // Update achievements array with any new achievements
            this.achievements.forEach(achievement => {
                const savedAchievement = this.playerData.achievements.find(a => a.id === achievement.id);
                if (savedAchievement) {
                    achievement.achieved = savedAchievement.achieved;
                }
            });
        }
    }
    
    /**
     * Save player data to localStorage
     */
    savePlayerData() {
        localStorage.setItem('memoryGameProgression', JSON.stringify(this.playerData));
    }
    
    /**
     * Check and update daily challenge
     */
    checkDailyChallenge() {
        const today = new Date().toDateString();
        
        // Check if we need to generate a new daily challenge
        if (!this.playerData.dailyChallenge.lastUpdated || 
            this.playerData.dailyChallenge.lastUpdated !== today) {
            
            // Generate new challenge
            const randomChallenge = this.dailyChallengeTemplates[
                Math.floor(Math.random() * this.dailyChallengeTemplates.length)
            ];
            
            this.playerData.dailyChallenge = {
                lastUpdated: today,
                current: randomChallenge,
                completed: false
            };
            
            this.savePlayerData();
        }
    }
    
    /**
     * Render progression UI elements
     */
    renderProgressionUI() {
        // Render level and XP in header
        this.renderLevelInfo();
        
        // Render daily challenge
        this.renderDailyChallenge();
        
        // Render achievements in profile modal
        this.renderAchievements();
        
        // Render themes and card backs in settings modal
        this.renderCustomizationOptions();
    }
    
    /**
     * Render level and XP information
     */
    renderLevelInfo() {
        const levelContainer = document.getElementById('playerLevel');
        if (!levelContainer) return;
        
        const currentLevel = this.playerData.level;
        const currentXP = this.playerData.experience;
        const nextLevelXP = this.levelRequirements[Math.min(currentLevel, this.levelRequirements.length - 1)];
        const prevLevelXP = this.levelRequirements[Math.max(0, currentLevel - 1)];
        const progress = nextLevelXP ? Math.floor(((currentXP - prevLevelXP) / (nextLevelXP - prevLevelXP)) * 100) : 100;
        
        levelContainer.innerHTML = `
            <div class="level-badge">Lvl ${currentLevel}</div>
            <div class="xp-bar-container">
                <div class="xp-bar" style="width: ${progress}%"></div>
                <div class="xp-text">${currentXP - prevLevelXP}/${nextLevelXP - prevLevelXP} XP</div>
            </div>
        `;
    }
    
    /**
     * Render daily challenge information
     */
    renderDailyChallenge() {
        const challengeContainer = document.getElementById('dailyChallenge');
        if (!challengeContainer) return;
        
        const challenge = this.playerData.dailyChallenge.current;
        if (!challenge) return;
        
        challengeContainer.innerHTML = `
            <h3>Daily Challenge</h3>
            <div class="challenge-card ${this.playerData.dailyChallenge.completed ? 'completed' : ''}">
                <div class="challenge-header">
                    <span class="challenge-name">${challenge.name}</span>
                    <span class="challenge-reward">+${challenge.experienceReward} XP</span>
                </div>
                <div class="challenge-description">${challenge.description}</div>
                <div class="challenge-status">
                    ${this.playerData.dailyChallenge.completed ? 
                        '<span class="completed-text">Completed!</span>' : 
                        '<span class="pending-text">In Progress</span>'}
                </div>
            </div>
        `;
    }
    
    /**
     * Render achievements in profile modal
     */
    renderAchievements() {
        const achievementsContainer = document.getElementById('achievementsList');
        if (!achievementsContainer) return;
        
        achievementsContainer.innerHTML = '';
        
        this.achievements.forEach(achievement => {
            const achievementElement = document.createElement('div');
            achievementElement.className = `achievement-card ${achievement.achieved ? 'achieved' : 'locked'}`;
            
            achievementElement.innerHTML = `
                <div class="achievement-icon">${achievement.icon}</div>
                <div class="achievement-content">
                    <div class="achievement-name">${achievement.name}</div>
                    <div class="achievement-description">${achievement.description}</div>
                    <div class="achievement-reward">+${achievement.experienceReward} XP</div>
                </div>
                <div class="achievement-status">
                    ${achievement.achieved ? 
                        '<span class="status-icon">✓</span>' : 
                        '<span class="status-icon">🔒</span>'}
                </div>
            `;
            
            achievementsContainer.appendChild(achievementElement);
        });
    }
    
    /**
     * Render customization options in settings modal
     */
    renderCustomizationOptions() {
        // Render themes
        const themesContainer = document.getElementById('themesList');
        if (themesContainer) {
            themesContainer.innerHTML = '';
            
            this.themes.forEach(theme => {
                const isUnlocked = this.playerData.level >= theme.levelRequired;
                const isActive = this.playerData.activeTheme === theme.id || 
                                (!this.playerData.activeTheme && theme.id === 'default');
                
                const themeElement = document.createElement('div');
                themeElement.className = `theme-card ${isUnlocked ? 'unlocked' : 'locked'} ${isActive ? 'active' : ''}`;
                themeElement.dataset.themeId = theme.id;
                
                themeElement.innerHTML = `
                    <div class="theme-name">${theme.name}</div>
                    <div class="theme-description">${theme.description}</div>
                    ${!isUnlocked ? 
                        `<div class="theme-lock-info">Unlocks at Level ${theme.levelRequired}</div>` : 
                        ''}
                    ${isActive ? 
                        '<div class="theme-active-indicator">Active</div>' : 
                        ''}
                `;
                
                if (isUnlocked) {
                    themeElement.addEventListener('click', () => this.setTheme(theme.id));
                }
                
                themesContainer.appendChild(themeElement);
            });
        }
        
        // Render card backs
        const cardBacksContainer = document.getElementById('cardBacksList');
        if (cardBacksContainer) {
            cardBacksContainer.innerHTML = '';
            
            this.cardBacks.forEach(cardBack => {
                const unlockedByAchievement = cardBack.unlockedBy ? 
                    this.achievements.find(a => a.id === cardBack.unlockedBy) : null;
                const isUnlocked = cardBack.unlockedBy === null || 
                    (unlockedByAchievement && unlockedByAchievement.achieved);
                const isActive = this.playerData.activeCardBack === cardBack.id || 
                                (!this.playerData.activeCardBack && cardBack.id === 'default');
                
                const cardBackElement = document.createElement('div');
                cardBackElement.className = `card-back-option ${isUnlocked ? 'unlocked' : 'locked'} ${isActive ? 'active' : ''}`;
                cardBackElement.dataset.cardBackId = cardBack.id;
                
                cardBackElement.innerHTML = `
                    <div class="card-back-preview ${cardBack.cssClass}"></div>
                    <div class="card-back-info">
                        <div class="card-back-name">${cardBack.name}</div>
                        <div class="card-back-description">${cardBack.description}</div>
                        ${!isUnlocked && unlockedByAchievement ? 
                            `<div class="card-back-lock-info">Unlock: ${unlockedByAchievement.name}</div>` : 
                            ''}
                        ${isActive ? 
                            '<div class="card-back-active-indicator">Active</div>' : 
                            ''}
                    </div>
                `;
                
                if (isUnlocked) {
                    cardBackElement.addEventListener('click', () => this.setCardBack(cardBack.id));
                }
                
                cardBacksContainer.appendChild(cardBackElement);
            });
        }
    }
    
    /**
     * Apply the current theme
     */
    applyTheme() {
        const activeThemeId = this.playerData.activeTheme || 'default';
        const theme = this.themes.find(t => t.id === activeThemeId);
        
        if (theme && theme.cssVariables) {
            const root = document.documentElement;
            
            // Apply CSS variables
            Object.entries(theme.cssVariables).forEach(([variable, value]) => {
                root.style.setProperty(variable, value);
            });
        }
    }
    
    /**
     * Apply the current card back
     */
    applyCardBack() {
        const activeCardBackId = this.playerData.activeCardBack || 'default';
        const cardBack = this.cardBacks.find(c => c.id === activeCardBackId);
        
        if (cardBack) {
            // Remove all card back classes
            document.body.classList.remove(...this.cardBacks.map(c => c.cssClass).filter(Boolean));
            
            // Add active card back class
            if (cardBack.cssClass) {
                document.body.classList.add(cardBack.cssClass);
            }
        }
    }
    
    /**
     * Set active theme
     * @param {string} themeId - Theme ID
     */
    setTheme(themeId) {
        const theme = this.themes.find(t => t.id === themeId);
        
        if (theme && this.playerData.level >= theme.levelRequired) {
            this.playerData.activeTheme = themeId;
            this.savePlayerData();
            this.applyTheme();
            this.renderCustomizationOptions();
        }
    }
    
    /**
     * Set active card back
     * @param {string} cardBackId - Card back ID
     */
    setCardBack(cardBackId) {
        const cardBack = this.cardBacks.find(c => c.id === cardBackId);
        const unlockedByAchievement = cardBack.unlockedBy ? 
            this.achievements.find(a => a.id === cardBack.unlockedBy) : null;
        
        if (cardBack && (cardBack.unlockedBy === null || 
            (unlockedByAchievement && unlockedByAchievement.achieved))) {
            this.playerData.activeCardBack = cardBackId;
            this.savePlayerData();
            this.applyCardBack();
            this.renderCustomizationOptions();
        }
    }
    
    /**
     * Process game completion and update progression
     * @param {Object} gameStats - Game statistics
     */
    processGameCompletion(gameStats) {
        // Update player stats
        this.playerData.totalGamesPlayed++;
        
        // Calculate base XP reward
        let xpReward = this.calculateXPReward(gameStats);
        
        // Check for achievements
        const newAchievements = this.checkAchievements(gameStats);
        
        // Add achievement XP rewards
        newAchievements.forEach(achievement => {
            xpReward += achievement.experienceReward;
        });
        
        // Check daily challenge
        if (!this.playerData.dailyChallenge.completed && 
            this.playerData.dailyChallenge.current && 
            this.playerData.dailyChallenge.current.checkCompletion(gameStats)) {
            
            this.playerData.dailyChallenge.completed = true;
            xpReward += this.playerData.dailyChallenge.current.experienceReward;
        }
        
        // Award XP and check for level up
        this.awardExperience(xpReward);
        
        // Save player data
        this.savePlayerData();
        
        // Update UI
        this.renderProgressionUI();
        
        // Return summary for display
        return {
            xpGained: xpReward,
            newAchievements: newAchievements,
            leveledUp: this.checkLevelUp(),
            dailyChallengeCompleted: this.playerData.dailyChallenge.completed
        };
    }
    
    /**
     * Calculate XP reward based on game statistics
     * @param {Object} gameStats - Game statistics
     * @returns {number} XP reward
     */
    calculateXPReward(gameStats) {
        let baseXP = 0;
        
        // Base XP by difficulty
        switch (gameStats.difficulty) {
            case 'easy': baseXP = 20; break;
            case 'medium': baseXP = 30; break;
            case 'hard': baseXP = 50; break;
            case 'expert': baseXP = 80; break;
            default: baseXP = 20;
        }
        
        // Adjust for game mode
        if (gameStats.gameMode === 'timeAttack') {
            baseXP *= 1.2; // 20% bonus for time attack
        }
        
        // Adjust for efficiency (moves)
        const perfectMoves = gameStats.totalPairs * 2; // Minimum possible moves
        const moveEfficiency = Math.max(0, 1 - ((gameStats.moves - perfectMoves) / (perfectMoves * 2)));
        baseXP *= (1 + moveEfficiency * 0.5); // Up to 50% bonus for perfect moves
        
        // Adjust for time (faster is better, but with diminishing returns)
        let timeMultiplier = 1;
        if (gameStats.gameMode === 'classic') {
            const expectedTime = gameStats.totalPairs * 5; // Rough estimate of expected time
            timeMultiplier = Math.max(0.5, Math.min(1.5, expectedTime / gameStats.time));
        }
        baseXP *= timeMultiplier;
        
        // Bonus for combos
        if (gameStats.highestCombo > 1) {
            baseXP *= (1 + (gameStats.highestCombo - 1) * 0.1); // 10% per combo level
        }
        
        return Math.round(baseXP);
    }
    
    /**
     * Check for newly completed achievements
     * @param {Object} gameStats - Game statistics
     * @returns {Array} Newly completed achievements
     */
    checkAchievements(gameStats) {
        const newAchievements = [];
        
        // Compile stats for achievement checks
        const stats = {
            gamesPlayed: this.playerData.totalGamesPlayed + 1,
            gamesCompleted: this.playerData.totalGamesPlayed + 1,
            fastestTime: gameStats.time,
            perfectGames: gameStats.moves === gameStats.totalPairs * 2 ? 1 : 0,
            highestCombo: gameStats.highestCombo,
            expertGamesCompleted: gameStats.difficulty === 'expert' ? 1 : 0,
            highestTimeAttackScore: gameStats.gameMode === 'timeAttack' ? gameStats.score : 0,
            zenGamesCompleted: gameStats.gameMode === 'zen' ? 1 : 0,
            specialCardsMatched: gameStats.specialCardsMatched || 0,
            dailyChallengesCompleted: this.playerData.dailyChallenge.completed ? 1 : 0
        };
        
        // Check each achievement
        this.achievements.forEach(achievement => {
            if (!achievement.achieved && achievement.condition(stats)) {
                achievement.achieved = true;
                newAchievements.push(achievement);
                
                // Update player's achievements
                const playerAchievement = this.playerData.achievements.find(a => a.id === achievement.id);
                if (playerAchievement) {
                    playerAchievement.achieved = true;
                } else {
                    this.playerData.achievements.push({
                        id: achievement.id,
                        achieved: true,
                        date: new Date().toISOString()
                    });
                }
                
                // Check for unlocked card backs
                this.cardBacks.forEach(cardBack => {
                    if (cardBack.unlockedBy === achievement.id) {
                        if (!this.playerData.unlockedCardBacks.includes(cardBack.id)) {
                            this.playerData.unlockedCardBacks.push(cardBack.id);
                        }
                    }
                });
            }
        });
        
        return newAchievements;
    }
    
    /**
     * Award experience points to the player
     * @param {number} xp - Experience points to award
     */
    awardExperience(xp) {
        this.playerData.experience += xp;
        
        // Check for level up
        while (this.canLevelUp()) {
            this.levelUp();
        }
    }
    
    /**
     * Check if player can level up
     * @returns {boolean} Whether player can level up
     */
    canLevelUp() {
        const currentLevel = this.playerData.level;
        const nextLevelIndex = currentLevel;
        
        // Check if we have requirements for the next level
        if (nextLevelIndex >= this.levelRequirements.length) {
            return false;
        }
        
        return this.playerData.experience >= this.levelRequirements[nextLevelIndex];
    }
    
    /**
     * Level up the player
     */
    levelUp() {
        this.playerData.level++;
        
        // Check for newly unlocked themes
        this.themes.forEach(theme => {
            if (theme.levelRequired === this.playerData.level) {
                if (!this.playerData.unlockedThemes.includes(theme.id)) {
                    this.playerData.unlockedThemes.push(theme.id);
                }
            }
        });
    }
    
    /**
     * Check if player has leveled up since last check
     * @returns {boolean} Whether player has leveled up
     */
    checkLevelUp() {
        if (!this.lastKnownLevel) {
            this.lastKnownLevel = this.playerData.level;
            return false;
        }
        
        const hasLeveledUp = this.playerData.level > this.lastKnownLevel;
        this.lastKnownLevel = this.playerData.level;
        return hasLeveledUp;
    }
    
    /**
     * Show progression summary after game completion
     * @param {Object} summary - Progression summary
     */
    showProgressionSummary(summary) {
        const summaryContainer = document.createElement('div');
        summaryContainer.className = 'progression-summary';
        
        let summaryHTML = `
            <h3>Game Summary</h3>
            <div class="xp-reward">+${summary.xpGained} XP</div>
        `;
        
        if (summary.leveledUp) {
            summaryHTML += `
                <div class="level-up-notification">
                    <span class="level-up-icon">🎉</span>
                    <span>Level Up! You are now level ${this.playerData.level}</span>
                </div>
            `;
        }
        
        if (summary.newAchievements.length > 0) {
            summaryHTML += `<div class="new-achievements">`;
            summary.newAchievements.forEach(achievement => {
                summaryHTML += `
                    <div class="achievement-unlocked">
                        <span class="achievement-icon">${achievement.icon}</span>
                        <span class="achievement-name">${achievement.name}</span>
                        <span class="achievement-xp">+${achievement.experienceReward} XP</span>
                    </div>
                `;
            });
            summaryHTML += `</div>`;
        }
        
        if (summary.dailyChallengeCompleted) {
            summaryHTML += `
                <div class="challenge-completed">
                    <span class="challenge-icon">🏆</span>
                    <span>Daily Challenge Completed!</span>
                    <span class="challenge-xp">+${this.playerData.dailyChallenge.current.experienceReward} XP</span>
                </div>
            `;
        }
        
        summaryContainer.innerHTML = summaryHTML;
        document.body.appendChild(summaryContainer);
        
        // Show summary with animation
        setTimeout(() => {
            summaryContainer.classList.add('show');
            
            // Remove after delay
            setTimeout(() => {
                summaryContainer.classList.remove('show');
                setTimeout(() => {
                    summaryContainer.remove();
                }, 500);
            }, 5000);
        }, 10);
    }
}

// Export progression system
window.ProgressionSystem = ProgressionSystem;
