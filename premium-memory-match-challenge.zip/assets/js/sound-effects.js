/**
 * Memory Match Challenge - Sound Effects System
 * Implementation of audio feedback for game events
 */

class SoundEffects {
    constructor() {
        this.sounds = {};
        this.musicTracks = {};
        this.currentMusic = null;
        this.isMuted = false;
        this.volume = 0.5;
        this.musicVolume = 0.3;
        
        // Initialize sound effects
        this.initSounds();
    }
    
    /**
     * Initialize sound effects
     */
    initSounds() {
        // Card sounds
        this.loadSound('cardFlip', 'https://assets.mixkit.co/sfx/preview/mixkit-light-card-flip-1998.mp3');
        this.loadSound('cardMatch', 'https://assets.mixkit.co/sfx/preview/mixkit-magical-coin-win-1936.mp3');
        this.loadSound('cardMismatch', 'https://assets.mixkit.co/sfx/preview/mixkit-wrong-answer-fail-notification-946.mp3');
        
        // UI sounds
        this.loadSound('click', 'https://assets.mixkit.co/sfx/preview/mixkit-modern-click-box-check-1120.mp3');
        this.loadSound('hover', 'https://assets.mixkit.co/sfx/preview/mixkit-software-interface-start-2574.mp3');
        
        // Game events
        this.loadSound('gameStart', 'https://assets.mixkit.co/sfx/preview/mixkit-arcade-game-complete-or-approved-mission-205.mp3');
        this.loadSound('gameWin', 'https://assets.mixkit.co/sfx/preview/mixkit-winning-chimes-2015.mp3');
        this.loadSound('timeUp', 'https://assets.mixkit.co/sfx/preview/mixkit-game-over-trombone-1940.mp3');
        
        // Special effects
        this.loadSound('specialCard', 'https://assets.mixkit.co/sfx/preview/mixkit-fairy-magic-sparkle-871.mp3');
        this.loadSound('combo', 'https://assets.mixkit.co/sfx/preview/mixkit-unlock-game-notification-253.mp3');
        this.loadSound('powerUp', 'https://assets.mixkit.co/sfx/preview/mixkit-instant-win-2021.mp3');
        this.loadSound('levelUp', 'https://assets.mixkit.co/sfx/preview/mixkit-video-game-win-2016.mp3');
        this.loadSound('achievement', 'https://assets.mixkit.co/sfx/preview/mixkit-achievement-bell-600.mp3');
        
        // Background music
        this.loadMusic('casual', 'https://assets.mixkit.co/music/preview/mixkit-games-worldbeat-466.mp3');
        this.loadMusic('intense', 'https://assets.mixkit.co/music/preview/mixkit-driving-ambition-32.mp3');
        this.loadMusic('relaxed', 'https://assets.mixkit.co/music/preview/mixkit-serene-view-443.mp3');
    }
    
    /**
     * Load a sound effect
     * @param {string} name - Sound name
     * @param {string} url - Sound URL
     */
    loadSound(name, url) {
        const audio = new Audio();
        audio.src = url;
        audio.preload = 'auto';
        this.sounds[name] = audio;
    }
    
    /**
     * Load a music track
     * @param {string} name - Music name
     * @param {string} url - Music URL
     */
    loadMusic(name, url) {
        const audio = new Audio();
        audio.src = url;
        audio.preload = 'auto';
        audio.loop = true;
        audio.volume = this.musicVolume;
        this.musicTracks[name] = audio;
    }
    
    /**
     * Play a sound effect
     * @param {string} name - Sound name
     * @param {number} volume - Volume override (optional)
     */
    play(name, volume = null) {
        if (this.isMuted) return;
        
        const sound = this.sounds[name];
        if (sound) {
            // Create a clone to allow overlapping sounds
            const soundClone = sound.cloneNode();
            soundClone.volume = volume !== null ? volume : this.volume;
            
            // Play the sound
            soundClone.play().catch(error => {
                console.warn(`Error playing sound ${name}:`, error);
            });
            
            // Remove the clone after it finishes playing
            soundClone.onended = () => {
                soundClone.remove();
            };
        }
    }
    
    /**
     * Play background music
     * @param {string} name - Music name
     */
    playMusic(name) {
        if (this.isMuted) return;
        
        // Stop current music if playing
        this.stopMusic();
        
        const music = this.musicTracks[name];
        if (music) {
            this.currentMusic = name;
            music.volume = this.musicVolume;
            music.currentTime = 0;
            music.play().catch(error => {
                console.warn(`Error playing music ${name}:`, error);
            });
        }
    }
    
    /**
     * Stop current background music
     */
    stopMusic() {
        if (this.currentMusic) {
            const music = this.musicTracks[this.currentMusic];
            if (music) {
                music.pause();
                music.currentTime = 0;
            }
            this.currentMusic = null;
        }
    }
    
    /**
     * Set master volume
     * @param {number} volume - Volume level (0-1)
     */
    setVolume(volume) {
        this.volume = Math.max(0, Math.min(1, volume));
    }
    
    /**
     * Set music volume
     * @param {number} volume - Volume level (0-1)
     */
    setMusicVolume(volume) {
        this.musicVolume = Math.max(0, Math.min(1, volume));
        
        // Update current music if playing
        if (this.currentMusic) {
            const music = this.musicTracks[this.currentMusic];
            if (music) {
                music.volume = this.musicVolume;
            }
        }
    }
    
    /**
     * Toggle mute state
     * @returns {boolean} New mute state
     */
    toggleMute() {
        this.isMuted = !this.isMuted;
        
        // Update current music if playing
        if (this.currentMusic) {
            const music = this.musicTracks[this.currentMusic];
            if (music) {
                if (this.isMuted) {
                    music.pause();
                } else {
                    music.play().catch(error => {
                        console.warn(`Error resuming music ${this.currentMusic}:`, error);
                    });
                }
            }
        }
        
        return this.isMuted;
    }
    
    /**
     * Set mute state
     * @param {boolean} muted - Mute state
     */
    setMute(muted) {
        if (this.isMuted !== muted) {
            this.toggleMute();
        }
    }
    
    /**
     * Play appropriate music for game mode
     * @param {string} gameMode - Game mode
     */
    playMusicForGameMode(gameMode) {
        switch (gameMode) {
            case 'classic':
                this.playMusic('casual');
                break;
            case 'timeAttack':
                this.playMusic('intense');
                break;
            case 'zen':
                this.playMusic('relaxed');
                break;
            default:
                this.playMusic('casual');
        }
    }
}

// Export sound effects
window.SoundEffects = SoundEffects;
