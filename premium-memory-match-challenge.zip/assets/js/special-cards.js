/**
 * Memory Match Challenge - Special Cards
 * Implementation of special card types and effects
 */

class SpecialCards {
    constructor(gameInstance) {
        this.game = gameInstance;
        
        // Special card types
        this.types = [
            {
                type: 'wildcard',
                emoji: '🃏',
                name: 'Wild Card',
                description: 'Matches with any card',
                rarity: 'rare',
                effect: this.wildcardEffect.bind(this)
            },
            {
                type: 'reveal',
                emoji: '👁️',
                name: 'Revealer',
                description: 'Reveals all cards briefly',
                rarity: 'uncommon',
                effect: this.revealEffect.bind(this)
            },
            {
                type: 'bonus',
                emoji: '💎',
                name: 'Bonus Gem',
                description: 'Grants extra points when matched',
                rarity: 'uncommon',
                effect: this.bonusEffect.bind(this)
            },
            {
                type: 'time',
                emoji: '⏱️',
                name: 'Time Warp',
                description: 'Adds or reduces time based on game mode',
                rarity: 'rare',
                effect: this.timeEffect.bind(this)
            },
            {
                type: 'shuffle',
                emoji: '🔄',
                name: 'Shuffler',
                description: 'Shuffles all unmatched cards',
                rarity: 'rare',
                effect: this.shuffleEffect.bind(this)
            },
            {
                type: 'freeze',
                emoji: '❄️',
                name: 'Freezer',
                description: 'Freezes a random card in place',
                rarity: 'uncommon',
                effect: this.freezeEffect.bind(this)
            }
        ];
        
        // Probability weights based on rarity
        this.rarityWeights = {
            common: 0.6,
            uncommon: 0.3,
            rare: 0.1
        };
    }
    
    /**
     * Get a random special card based on rarity weights
     * @returns {Object} Special card object
     */
    getRandomSpecialCard() {
        // Determine rarity first
        const rarityRoll = Math.random();
        let selectedRarity;
        
        if (rarityRoll < this.rarityWeights.rare) {
            selectedRarity = 'rare';
        } else if (rarityRoll < this.rarityWeights.rare + this.rarityWeights.uncommon) {
            selectedRarity = 'uncommon';
        } else {
            selectedRarity = 'common';
        }
        
        // Filter cards by selected rarity
        const cardsOfRarity = this.types.filter(card => card.rarity === selectedRarity);
        
        // Select a random card from the filtered list
        return cardsOfRarity[Math.floor(Math.random() * cardsOfRarity.length)];
    }
    
    /**
     * Create special card pairs
     * @param {number} count - Number of special card pairs to create
     * @returns {Array} Array of special card pairs
     */
    createSpecialCardPairs(count) {
        const specialCards = [];
        
        for (let i = 0; i < count; i++) {
            const specialCard = this.getRandomSpecialCard();
            specialCards.push(specialCard, specialCard); // Add pair
        }
        
        return specialCards;
    }
    
    /**
     * Wild card effect - matches with any card
     * @param {Object} specialCard - The special card
     * @param {Object} otherCard - The other card
     * @param {HTMLElement} specialCardElement - The special card element
     * @param {HTMLElement} otherCardElement - The other card element
     */
    wildcardEffect(specialCard, otherCard, specialCardElement, otherCardElement) {
        // Wild card always matches
        setTimeout(() => {
            specialCard.isMatched = true;
            otherCard.isMatched = true;
            this.game.matchedPairs++;
            
            // Bonus points for wildcard match
            this.game.score += 20 * this.game.getDifficultyMultiplier();
            this.game.updateGameInfo();
            
            // Use animation if available
            if (this.game.animationController) {
                this.game.animationController.cardMatchAnimation(specialCardElement, otherCardElement);
            } else {
                specialCardElement.classList.add('matched');
                otherCardElement.classList.add('matched');
            }
            
            // Check if game is complete
            if (this.game.matchedPairs === this.game.totalPairs) {
                this.game.endGame();
            }
            
            this.game.flippedCards = [];
            this.game.isLocked = false;
            this.game.specialCardActive = false;
        }, 500);
    }
    
    /**
     * Reveal effect - reveals all cards briefly
     * @param {Object} specialCard - The special card
     * @param {Object} otherCard - The other card
     * @param {HTMLElement} specialCardElement - The special card element
     * @param {HTMLElement} otherCardElement - The other card element
     */
    revealEffect(specialCard, otherCard, specialCardElement, otherCardElement) {
        setTimeout(() => {
            // Create a flash effect
            const flash = document.createElement('div');
            flash.className = 'flash-effect';
            document.body.appendChild(flash);
            
            setTimeout(() => {
                flash.remove();
                
                // Flip all unmatched cards
                const unmatched = this.game.cards.filter(c => !c.isMatched && !c.isFlipped);
                unmatched.forEach(c => {
                    c.isFlipped = true;
                });
                this.game.renderCards();
                
                // Flip them back after a delay
                setTimeout(() => {
                    unmatched.forEach(c => {
                        c.isFlipped = false;
                    });
                    
                    // Keep the special card and its pair flipped
                    specialCard.isFlipped = true;
                    otherCard.isFlipped = true;
                    
                    this.game.renderCards();
                    this.game.flippedCards = [specialCard, otherCard];
                    this.game.isLocked = false;
                    this.game.specialCardActive = false;
                    
                    // Continue checking for match
                    this.game.checkForMatch();
                }, 2000);
            }, 300);
        }, 500);
    }
    
    /**
     * Bonus effect - grants extra points when matched
     * @param {Object} specialCard - The special card
     * @param {Object} otherCard - The other card
     * @param {HTMLElement} specialCardElement - The special card element
     * @param {HTMLElement} otherCardElement - The other card element
     */
    bonusEffect(specialCard, otherCard, specialCardElement, otherCardElement) {
        if (specialCard.emoji === otherCard.emoji) {
            setTimeout(() => {
                specialCard.isMatched = true;
                otherCard.isMatched = true;
                this.game.matchedPairs++;
                
                // Extra bonus points
                const bonusPoints = 50 * this.game.getDifficultyMultiplier();
                this.game.score += bonusPoints;
                this.game.updateGameInfo();
                
                // Show bonus points animation
                this.showPointsAnimation(bonusPoints, otherCardElement);
                
                // Use animation if available
                if (this.game.animationController) {
                    this.game.animationController.cardMatchAnimation(specialCardElement, otherCardElement);
                } else {
                    specialCardElement.classList.add('matched');
                    otherCardElement.classList.add('matched');
                }
                
                // Check if game is complete
                if (this.game.matchedPairs === this.game.totalPairs) {
                    this.game.endGame();
                }
                
                this.game.flippedCards = [];
                this.game.isLocked = false;
                this.game.specialCardActive = false;
            }, 500);
        } else {
            // No match
            setTimeout(() => {
                // Use animation if available
                if (this.game.animationController) {
                    this.game.animationController.cardMismatchAnimation(specialCardElement, otherCardElement);
                } else {
                    specialCard.isFlipped = false;
                    otherCard.isFlipped = false;
                    this.game.renderCards();
                }
                
                this.game.flippedCards = [];
                this.game.isLocked = false;
                this.game.specialCardActive = false;
            }, 1000);
        }
    }
    
    /**
     * Time effect - adds or reduces time based on game mode
     * @param {Object} specialCard - The special card
     * @param {Object} otherCard - The other card
     * @param {HTMLElement} specialCardElement - The special card element
     * @param {HTMLElement} otherCardElement - The other card element
     */
    timeEffect(specialCard, otherCard, specialCardElement, otherCardElement) {
        if (specialCard.emoji === otherCard.emoji) {
            setTimeout(() => {
                specialCard.isMatched = true;
                otherCard.isMatched = true;
                this.game.matchedPairs++;
                
                // Time effect based on game mode
                if (this.game.gameMode === 'timeAttack') {
                    // Add time in time attack mode
                    const timeBonus = 10;
                    this.game.seconds += timeBonus;
                    
                    // Show time bonus animation
                    this.showTimeAnimation(timeBonus, true);
                } else {
                    // Reduce time in classic mode (as a bonus)
                    const timeReduction = 5;
                    this.game.seconds = Math.max(0, this.game.seconds - timeReduction);
                    
                    // Show time reduction animation
                    this.showTimeAnimation(timeReduction, false);
                }
                
                // Regular points
                this.game.score += 15 * this.game.getDifficultyMultiplier();
                this.game.updateGameInfo();
                
                // Use animation if available
                if (this.game.animationController) {
                    this.game.animationController.cardMatchAnimation(specialCardElement, otherCardElement);
                } else {
                    specialCardElement.classList.add('matched');
                    otherCardElement.classList.add('matched');
                }
                
                // Check if game is complete
                if (this.game.matchedPairs === this.game.totalPairs) {
                    this.game.endGame();
                }
                
                this.game.flippedCards = [];
                this.game.isLocked = false;
                this.game.specialCardActive = false;
            }, 500);
        } else {
            // No match
            setTimeout(() => {
                // Use animation if available
                if (this.game.animationController) {
                    this.game.animationController.cardMismatchAnimation(specialCardElement, otherCardElement);
                } else {
                    specialCard.isFlipped = false;
                    otherCard.isFlipped = false;
                    this.game.renderCards();
                }
                
                this.game.flippedCards = [];
                this.game.isLocked = false;
                this.game.specialCardActive = false;
            }, 1000);
        }
    }
    
    /**
     * Shuffle effect - shuffles all unmatched cards
     * @param {Object} specialCard - The special card
     * @param {Object} otherCard - The other card
     * @param {HTMLElement} specialCardElement - The special card element
     * @param {HTMLElement} otherCardElement - The other card element
     */
    shuffleEffect(specialCard, otherCard, specialCardElement, otherCardElement) {
        if (specialCard.emoji === otherCard.emoji) {
            setTimeout(() => {
                specialCard.isMatched = true;
                otherCard.isMatched = true;
                this.game.matchedPairs++;
                
                // Regular points
                this.game.score += 15 * this.game.getDifficultyMultiplier();
                this.game.updateGameInfo();
                
                // Use animation if available
                if (this.game.animationController) {
                    this.game.animationController.cardMatchAnimation(specialCardElement, otherCardElement);
                } else {
                    specialCardElement.classList.add('matched');
                    otherCardElement.classList.add('matched');
                }
                
                // Shuffle animation and effect
                this.showShuffleAnimation(() => {
                    // Get unmatched cards
                    const unmatchedCards = this.game.cards.filter(c => !c.isMatched);
                    
                    // Get emojis from unmatched cards
                    const unmatchedEmojis = unmatchedCards.map(c => c.emoji);
                    
                    // Shuffle emojis
                    const shuffledEmojis = [...unmatchedEmojis].sort(() => 0.5 - Math.random());
                    
                    // Reassign emojis to unmatched cards
                    unmatchedCards.forEach((card, index) => {
                        card.emoji = shuffledEmojis[index];
                    });
                    
                    // Render cards
                    this.game.renderCards();
                    
                    // Check if game is complete
                    if (this.game.matchedPairs === this.game.totalPairs) {
                        this.game.endGame();
                    }
                    
                    this.game.flippedCards = [];
                    this.game.isLocked = false;
                    this.game.specialCardActive = false;
                });
            }, 500);
        } else {
            // No match
            setTimeout(() => {
                // Use animation if available
                if (this.game.animationController) {
                    this.game.animationController.cardMismatchAnimation(specialCardElement, otherCardElement);
                } else {
                    specialCard.isFlipped = false;
                    otherCard.isFlipped = false;
                    this.game.renderCards();
                }
                
                this.game.flippedCards = [];
                this.game.isLocked = false;
                this.game.specialCardActive = false;
            }, 1000);
        }
    }
    
    /**
     * Freeze effect - freezes a random card in place
     * @param {Object} specialCard - The special card
     * @param {Object} otherCard - The other card
     * @param {HTMLElement} specialCardElement - The special card element
     * @param {HTMLElement} otherCardElement - The other card element
     */
    freezeEffect(specialCard, otherCard, specialCardElement, otherCardElement) {
        if (specialCard.emoji === otherCard.emoji) {
            setTimeout(() => {
                specialCard.isMatched = true;
                otherCard.isMatched = true;
                this.game.matchedPairs++;
                
                // Regular points
                this.game.score += 15 * this.game.getDifficultyMultiplier();
                this.game.updateGameInfo();
                
                // Use animation if available
                if (this.game.animationController) {
                    this.game.animationController.cardMatchAnimation(specialCardElement, otherCardElement);
                } else {
                    specialCardElement.classList.add('matched');
                    otherCardElement.classList.add('matched');
                }
                
                // Find an unmatched card to freeze
                const unmatchedCards = this.game.cards.filter(c => !c.isMatched && c.id !== specialCard.id && c.id !== otherCard.id);
                
                if (unmatchedCards.length > 0) {
                    // Select a random card to freeze
                    const randomIndex = Math.floor(Math.random() * unmatchedCards.length);
                    const cardToFreeze = unmatchedCards[randomIndex];
                    
                    // Freeze the card (flip it and keep it flipped)
                    cardToFreeze.isFlipped = true;
                    cardToFreeze.isFrozen = true;
                    
                    // Show freeze animation
                    const cardElement = document.querySelector(`.card[data-id="${cardToFreeze.id}"]`);
                    this.showFreezeAnimation(cardElement);
                    
                    // Render cards
                    this.game.renderCards();
                }
                
                // Check if game is complete
                if (this.game.matchedPairs === this.game.totalPairs) {
                    this.game.endGame();
                }
                
                this.game.flippedCards = [];
                this.game.isLocked = false;
                this.game.specialCardActive = false;
            }, 500);
        } else {
            // No match
            setTimeout(() => {
                // Use animation if available
                if (this.game.animationController) {
                    this.game.animationController.cardMismatchAnimation(specialCardElement, otherCardElement);
                } else {
                    specialCard.isFlipped = false;
                    otherCard.isFlipped = false;
                    this.game.renderCards();
                }
                
                this.game.flippedCards = [];
                this.game.isLocked = false;
                this.game.specialCardActive = false;
            }, 1000);
        }
    }
    
    /**
     * Show points animation
     * @param {number} points - Points to show
     * @param {HTMLElement} element - Element to show animation near
     */
    showPointsAnimation(points, element) {
        const rect = element.getBoundingClientRect();
        const pointsElement = document.createElement('div');
        pointsElement.className = 'points-animation';
        pointsElement.textContent = `+${points}`;
        pointsElement.style.left = `${rect.left + rect.width / 2}px`;
        pointsElement.style.top = `${rect.top}px`;
        document.body.appendChild(pointsElement);
        
        // Animate and remove
        setTimeout(() => {
            pointsElement.style.transform = 'translateY(-50px)';
            pointsElement.style.opacity = '0';
            
            setTimeout(() => {
                pointsElement.remove();
            }, 1000);
        }, 10);
    }
    
    /**
     * Show time animation
     * @param {number} time - Time amount
     * @param {boolean} isBonus - Whether it's a bonus (true) or reduction (false)
     */
    showTimeAnimation(time, isBonus) {
        const timerElement = document.getElementById('timer');
        const rect = timerElement.getBoundingClientRect();
        const timeElement = document.createElement('div');
        timeElement.className = 'time-animation';
        timeElement.textContent = isBonus ? `+${time}s` : `-${time}s`;
        timeElement.style.color = isBonus ? '#10b981' : '#ef4444';
        timeElement.style.left = `${rect.left + rect.width / 2}px`;
        timeElement.style.top = `${rect.top}px`;
        document.body.appendChild(timeElement);
        
        // Animate and remove
        setTimeout(() => {
            timeElement.style.transform = 'translateY(-30px)';
            timeElement.style.opacity = '0';
            
            setTimeout(() => {
                timeElement.remove();
            }, 1000);
        }, 10);
    }
    
    /**
     * Show shuffle animation
     * @param {Function} callback - Callback to execute after animation
     */
    showShuffleAnimation(callback) {
        const gameBoard = document.getElementById('gameBoard');
        const rect = gameBoard.getBoundingClientRect();
        const shuffleElement = document.createElement('div');
        shuffleElement.className = 'shuffle-animation';
        shuffleElement.textContent = '🔄';
        shuffleElement.style.left = `${rect.left + rect.width / 2}px`;
        shuffleElement.style.top = `${rect.top + rect.height / 2}px`;
        document.body.appendChild(shuffleElement);
        
        // Animate and remove
        setTimeout(() => {
            shuffleElement.style.transform = 'rotate(360deg) scale(2)';
            
            setTimeout(() => {
                shuffleElement.style.opacity = '0';
                
                setTimeout(() => {
                    shuffleElement.remove();
                    if (callback) callback();
                }, 300);
            }, 700);
        }, 10);
    }
    
    /**
     * Show freeze animation
     * @param {HTMLElement} element - Element to freeze
     */
    showFreezeAnimation(element) {
        element.classList.add('freezing');
        
        setTimeout(() => {
            element.classList.remove('freezing');
            element.classList.add('frozen');
        }, 1000);
    }
}

// Export special cards
window.SpecialCards = SpecialCards;
