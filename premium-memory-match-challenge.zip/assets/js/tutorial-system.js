/**
 * Memory Match Challenge - Tutorial System
 * Implementation of interactive tutorial for new players
 */

class TutorialSystem {
    constructor(gameInstance) {
        this.game = gameInstance;
        this.isActive = false;
        this.currentStep = 0;
        this.tutorialOverlay = null;
        this.highlightElement = null;
        
        // Tutorial steps with instructions and targets
        this.tutorialSteps = [
            {
                title: 'Welcome to Memory Match Challenge!',
                text: 'This tutorial will guide you through the basic gameplay and features.',
                target: null,
                position: 'center',
                action: null
            },
            {
                title: 'Game Objective',
                text: 'The goal is to find matching pairs of cards by flipping them over. Try to complete the game with the fewest moves and fastest time!',
                target: '#gameBoard',
                position: 'bottom',
                action: null
            },
            {
                title: 'Difficulty Levels',
                text: 'Choose your difficulty level. Higher difficulties have more cards and more complex patterns.',
                target: '.difficulty-selector',
                position: 'bottom',
                action: null
            },
            {
                title: 'Game Modes',
                text: 'Try different game modes: Classic (standard gameplay), Time Attack (race against the clock), or Zen Mode (relaxed play with no time pressure).',
                target: '.mode-selector',
                position: 'bottom',
                action: null
            },
            {
                title: 'Special Cards',
                text: 'Look out for special cards with unique effects! They can help you progress faster or add strategic depth.',
                target: '#gameBoard',
                position: 'bottom',
                action: 'showSpecialCard'
            },
            {
                title: 'Power-Ups',
                text: 'Use power-ups to gain advantages during gameplay. Each power-up has a different effect to help you.',
                target: '#powerUpsContainer',
                position: 'top',
                action: null
            },
            {
                title: 'Progression System',
                text: 'Earn experience points by completing games. Level up to unlock new themes, card backs, and other content!',
                target: '#playerLevel',
                position: 'bottom',
                action: null
            },
            {
                title: 'Daily Challenges',
                text: 'Complete daily challenges to earn bonus experience points and rewards.',
                target: '#dailyChallenge',
                position: 'bottom',
                action: null
            },
            {
                title: 'Achievements',
                text: 'Earn achievements by completing specific goals. Check your profile to see your progress!',
                target: '#profileBtn',
                position: 'top',
                action: null
            },
            {
                title: 'Ready to Play!',
                text: 'You\'re all set! Click "Start Game" to begin your Memory Match Challenge!',
                target: '#newGameBtn',
                position: 'top',
                action: null
            }
        ];
    }
    
    /**
     * Initialize tutorial system
     */
    init() {
        this.createTutorialUI();
        this.setupEventListeners();
    }
    
    /**
     * Create tutorial UI elements
     */
    createTutorialUI() {
        // Create tutorial button in main menu
        const controlsContainer = document.querySelector('.controls');
        if (controlsContainer) {
            const tutorialBtn = document.createElement('button');
            tutorialBtn.id = 'tutorialBtn';
            tutorialBtn.textContent = 'Tutorial';
            controlsContainer.appendChild(tutorialBtn);
        }
        
        // Create tutorial overlay
        const overlay = document.createElement('div');
        overlay.className = 'tutorial-overlay';
        overlay.style.display = 'none';
        
        // Create tutorial popup
        const popup = document.createElement('div');
        popup.className = 'tutorial-popup';
        
        popup.innerHTML = `
            <div class="tutorial-header">
                <h3 class="tutorial-title">Welcome</h3>
                <button class="tutorial-close">✕</button>
            </div>
            <div class="tutorial-content">
                <p class="tutorial-text">Welcome to the Memory Match Challenge tutorial!</p>
            </div>
            <div class="tutorial-footer">
                <div class="tutorial-progress">
                    <span class="current-step">1</span>/<span class="total-steps">10</span>
                </div>
                <div class="tutorial-buttons">
                    <button class="tutorial-prev" disabled>Previous</button>
                    <button class="tutorial-next">Next</button>
                </div>
            </div>
        `;
        
        overlay.appendChild(popup);
        document.body.appendChild(overlay);
        this.tutorialOverlay = overlay;
        
        // Create highlight element
        const highlight = document.createElement('div');
        highlight.className = 'tutorial-highlight';
        highlight.style.display = 'none';
        document.body.appendChild(highlight);
        this.highlightElement = highlight;
    }
    
    /**
     * Setup event listeners for tutorial UI
     */
    setupEventListeners() {
        // Start tutorial
        document.getElementById('tutorialBtn').addEventListener('click', () => {
            this.startTutorial();
        });
        
        // Close tutorial
        this.tutorialOverlay.querySelector('.tutorial-close').addEventListener('click', () => {
            this.endTutorial();
        });
        
        // Next step
        this.tutorialOverlay.querySelector('.tutorial-next').addEventListener('click', () => {
            this.nextStep();
        });
        
        // Previous step
        this.tutorialOverlay.querySelector('.tutorial-prev').addEventListener('click', () => {
            this.prevStep();
        });
        
        // Close on escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isActive) {
                this.endTutorial();
            }
        });
    }
    
    /**
     * Start the tutorial
     */
    startTutorial() {
        this.isActive = true;
        this.currentStep = 0;
        
        // Reset game to a clean state
        this.game.newGame();
        
        // Show tutorial overlay
        this.tutorialOverlay.style.display = 'flex';
        
        // Show first step
        this.showStep(0);
        
        // Play sound
        if (window.soundEffects) {
            window.soundEffects.play('click');
        }
    }
    
    /**
     * End the tutorial
     */
    endTutorial() {
        this.isActive = false;
        
        // Hide tutorial overlay
        this.tutorialOverlay.style.display = 'none';
        
        // Hide highlight
        this.highlightElement.style.display = 'none';
        
        // Play sound
        if (window.soundEffects) {
            window.soundEffects.play('click');
        }
    }
    
    /**
     * Show a specific tutorial step
     * @param {number} stepIndex - Index of the step to show
     */
    showStep(stepIndex) {
        if (stepIndex < 0 || stepIndex >= this.tutorialSteps.length) return;
        
        const step = this.tutorialSteps[stepIndex];
        this.currentStep = stepIndex;
        
        // Update tutorial content
        const popup = this.tutorialOverlay.querySelector('.tutorial-popup');
        popup.querySelector('.tutorial-title').textContent = step.title;
        popup.querySelector('.tutorial-text').textContent = step.text;
        
        // Update progress
        popup.querySelector('.current-step').textContent = stepIndex + 1;
        popup.querySelector('.total-steps').textContent = this.tutorialSteps.length;
        
        // Update buttons
        popup.querySelector('.tutorial-prev').disabled = stepIndex === 0;
        
        const nextButton = popup.querySelector('.tutorial-next');
        if (stepIndex === this.tutorialSteps.length - 1) {
            nextButton.textContent = 'Finish';
        } else {
            nextButton.textContent = 'Next';
        }
        
        // Position popup and highlight target element
        this.positionElements(step);
        
        // Execute step action if any
        if (step.action) {
            this.executeStepAction(step.action);
        }
    }
    
    /**
     * Position tutorial popup and highlight based on target element
     * @param {Object} step - Current tutorial step
     */
    positionElements(step) {
        const popup = this.tutorialOverlay.querySelector('.tutorial-popup');
        
        // Reset popup position
        popup.style.top = '';
        popup.style.left = '';
        popup.style.bottom = '';
        popup.style.right = '';
        popup.style.transform = '';
        
        // Hide highlight by default
        this.highlightElement.style.display = 'none';
        
        // If no target, center popup
        if (!step.target) {
            popup.style.top = '50%';
            popup.style.left = '50%';
            popup.style.transform = 'translate(-50%, -50%)';
            return;
        }
        
        // Find target element
        const targetElement = document.querySelector(step.target);
        if (!targetElement) return;
        
        // Get target element position
        const targetRect = targetElement.getBoundingClientRect();
        
        // Position highlight
        this.highlightElement.style.display = 'block';
        this.highlightElement.style.top = `${targetRect.top - 10}px`;
        this.highlightElement.style.left = `${targetRect.left - 10}px`;
        this.highlightElement.style.width = `${targetRect.width + 20}px`;
        this.highlightElement.style.height = `${targetRect.height + 20}px`;
        
        // Position popup based on specified position
        const popupRect = popup.getBoundingClientRect();
        
        switch (step.position) {
            case 'top':
                popup.style.bottom = `${window.innerHeight - targetRect.top + 20}px`;
                popup.style.left = `${targetRect.left + targetRect.width / 2}px`;
                popup.style.transform = 'translateX(-50%)';
                break;
            case 'bottom':
                popup.style.top = `${targetRect.bottom + 20}px`;
                popup.style.left = `${targetRect.left + targetRect.width / 2}px`;
                popup.style.transform = 'translateX(-50%)';
                break;
            case 'left':
                popup.style.right = `${window.innerWidth - targetRect.left + 20}px`;
                popup.style.top = `${targetRect.top + targetRect.height / 2}px`;
                popup.style.transform = 'translateY(-50%)';
                break;
            case 'right':
                popup.style.left = `${targetRect.right + 20}px`;
                popup.style.top = `${targetRect.top + targetRect.height / 2}px`;
                popup.style.transform = 'translateY(-50%)';
                break;
            default:
                popup.style.top = '50%';
                popup.style.left = '50%';
                popup.style.transform = 'translate(-50%, -50%)';
        }
        
        // Adjust if popup goes off screen
        const adjustedPopupRect = popup.getBoundingClientRect();
        
        if (adjustedPopupRect.right > window.innerWidth) {
            popup.style.left = '';
            popup.style.right = '20px';
            popup.style.transform = popup.style.transform.replace('translateX(-50%)', '');
        }
        
        if (adjustedPopupRect.left < 0) {
            popup.style.left = '20px';
            popup.style.right = '';
            popup.style.transform = popup.style.transform.replace('translateX(-50%)', '');
        }
        
        if (adjustedPopupRect.bottom > window.innerHeight) {
            popup.style.top = '';
            popup.style.bottom = '20px';
            popup.style.transform = popup.style.transform.replace('translateY(-50%)', '');
        }
        
        if (adjustedPopupRect.top < 0) {
            popup.style.top = '20px';
            popup.style.bottom = '';
            popup.style.transform = popup.style.transform.replace('translateY(-50%)', '');
        }
    }
    
    /**
     * Execute special actions for tutorial steps
     * @param {string} action - Action to execute
     */
    executeStepAction(action) {
        switch (action) {
            case 'showSpecialCard':
                // Create a temporary special card for demonstration
                const gameBoard = document.getElementById('gameBoard');
                if (gameBoard) {
                    const demoCard = document.createElement('div');
                    demoCard.className = 'card special-card special-wildcard';
                    demoCard.innerHTML = `
                        <div class="card-inner">
                            <div class="card-back"></div>
                            <div class="card-front">🃏</div>
                        </div>
                    `;
                    demoCard.style.position = 'absolute';
                    demoCard.style.top = '50%';
                    demoCard.style.left = '50%';
                    demoCard.style.transform = 'translate(-50%, -50%) scale(1.5)';
                    demoCard.style.zIndex = '100';
                    
                    gameBoard.appendChild(demoCard);
                    
                    // Flip the card after a short delay
                    setTimeout(() => {
                        demoCard.classList.add('flipped');
                        
                        // Remove the card when moving to next step
                        this.tutorialOverlay.querySelector('.tutorial-next').addEventListener('click', () => {
                            demoCard.remove();
                        }, { once: true });
                    }, 500);
                }
                break;
                
            // Add more actions as needed
        }
    }
    
    /**
     * Move to the next tutorial step
     */
    nextStep() {
        if (this.currentStep < this.tutorialSteps.length - 1) {
            this.showStep(this.currentStep + 1);
        } else {
            this.endTutorial();
        }
        
        // Play sound
        if (window.soundEffects) {
            window.soundEffects.play('click');
        }
    }
    
    /**
     * Move to the previous tutorial step
     */
    prevStep() {
        if (this.currentStep > 0) {
            this.showStep(this.currentStep - 1);
        }
        
        // Play sound
        if (window.soundEffects) {
            window.soundEffects.play('click');
        }
    }
}

// Export tutorial system
window.TutorialSystem = TutorialSystem;
